@extends('frontend.layout.master')
@section('pageTitle', $article->title)
@section('frontend-main')
    <div class="print-image text-center mb-3">
        <img src="{{ asset('frontend/img/222.png') }}">
    </div>
    <div class="total-artical">
        <div class="sobts">
            <div class="shobohat mb-5">
                <div class="container">
                    <div class="allshobohat">
                        <div class="title">
                            <h4 class="titleshop mt-5 mb-5">
                               {{ $article->title }}
                            </h4>
                        </div>
                        <div class="download-share d-colm">
                            <div class="row download-sharebox">
                                <div class="col-md-2 numbs minimartop">
                                    <i class="fas fa-stream"></i>
                                    {{ $article->id }}
                                </div>
                                <div class="vl"></div>
                                <div class="col-md-3 time-date minimartop">
                                    تاريخ النشر :
                                    {{  Carbon\Carbon::parse($article->created_at)->format('d-m-Y') }}
                                </div>
                                <div class="vl"></div>
                                <div class="col-md-6 views d-colm minimartop">
                                    المشاهدات :
                                    {{ $article->views }}
                                    <div class="icondownlod minimartop">
                                        <a style="cursor: pointer" type="button" data-toggle="modal" data-target="#share">
                                            <i class="fas fa-share-alt"></i>
                                        </a>
                                        <button style="font-size:inherit" class="btn p-0 m-0 mt-1" onclick="display()">
                                            <i class="fas fa-print"></i>
                                        </button>
                                        <a href="{{ route('article_pdf', $article->id )}}"><i class="fas fa-download"></i></a>
                                    </div>
                                </div>
                            </div>
                            <div class="textans textansmine">
                                <p>الحمد لله</p>
                                <p>
                                     <?php echo htmlspecialchars_decode($article->body) ?>
                                    
                                </p>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- share modale -->
    <div class="modal fade" id="share" tabindex="-1" role="dialog" aria-labelledby="share_title" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title text-primary" id="share_title">مشاركة المقال</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <?php $actual_link = "http://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]"; ?>
                    <ul>
                        <li title="مشاركة على فيس بوك">
                            <a href="https://www.facebook.com/sharer/sharer.php?u=<?= $actual_link; ?>" target="_blank">
                                <img src="{{ asset('frontend/img/facebook.png') }}">
                            </a>
                        </li>
                        <li title="مشاركة على تويتر">
                            <a href="http://twitter.com/home?status={{ $article->title }}+<?= $actual_link; ?>"
                               target="_blank">
                                <img src="{{ asset('frontend/img/twitter.png') }}">
                            </a>
                        </li>
                        <li title="مشاركة على الواتس اب">
                            <a href="https://api.whatsapp.com://send?text=<?= $actual_link; ?>" target="_blank" title="Share on whatsapp">
                                <img src="{{ asset('frontend/img/whatsapp.png') }}">
                            </a>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
@endsection
@section('frontend-footer')
    <script>
        function display() {
            window.print();
        }
    </script>
@endsection