<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>مرحبا بك في موقع الشبهات</title>
</head>
<body style="text-align: right">
<h4><?php echo e($title); ?></h4>
<p><?php echo e($msg); ?></p>
</body>
</html><?php /**PATH /home/nej76515k7il/public_html/resources/views/backend/subscribers/template.blade.php ENDPATH**/ ?>