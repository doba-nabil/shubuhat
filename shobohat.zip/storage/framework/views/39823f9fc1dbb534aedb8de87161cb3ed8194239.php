<?php if(session()->has('done')): ?>
    <p class="alert alert-success al"><?php echo e(session()->get('done')); ?></p>
<?php endif; ?>
<?php if(session()->has('error')): ?>
    <p class="alert alert-danger al"><?php echo e(session()->get('error')); ?></p>
<?php endif; ?><?php /**PATH /home/nej76515k7il/public_html/resources/views/common/done.blade.php ENDPATH**/ ?>