<?php $__env->startSection('pageTitle', 'المقالات'); ?>
<?php $__env->startSection('frontend-main'); ?>
    <!-- tabs  -->
    <div class="tabs">
        <div class="container">
            <div class="title">
                <h4 class="sectiontitle mb-5">
                    الفيديوهات
                </h4>
            </div>
            <div class="alltabs">
                <div class="content">
                    <div class="tab-content">
                        <div id="vdio" class=" tab-pane active">
                            <table id="example" class="table  table-borderless" style="width:100%">
                                <thead style="display:none;">
                                <tr>
                                    <th hidden></th>
                                    <th></th>
                                </tr>
                                </thead>
                                <tbody>

                                <?php $__currentLoopData = $videos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $video): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td hidden></td>
                                        <td>
                                            <div class="allvideo d-colm">
                                                <div class="rightsec d-colm">
                                                    <div class="secimg d-center">
                                                        <?php if(isset($video->mainImage->image)): ?>
                                                            <img src="<?php echo e(asset('pictures/media/' . $video->mainImage->image) ?? '--'); ?>"
                                                                 alt="<?php echo e($video->title); ?>">
                                                        <?php else: ?>
                                                            <img src="<?php echo e(asset('frontend/img/empty.png')); ?>" alt="" />
                                                        <?php endif; ?>
                                                        <div class="overlaysec"><i class="far fa-play-circle"></i></div>
                                                    </div>
                                                    <div class="viddeta d-colm">
                                                        <p class="namev"><?php echo e($video->title); ?></p>
                                                        <p class="catv"><?php echo e($video->category->title ?? ''); ?></p>
                                                        <p class="timev"><?php echo e(Carbon\Carbon::parse($video->created_at)->format('d-m-Y')); ?></p>
                                                    </div>
                                                </div>
                                                <div class="leftsec">
                                                    <!-- Button trigger modal -->
                                                    <button type="button" class="btn shahed" data-toggle="modal"
                                                            data-target="#video_modal<?php echo e($loop->index + 1); ?>">
                                                        مشاهدة
                                                    </button>
                                                    <!-- Modal -->
                                                    <div class="modal fade" id="video_modal<?php echo e($loop->index + 1); ?>"
                                                         tabindex="-1" role="dialog"
                                                         aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
                                                        <div class="modal-dialog modal-dialog-centered" role="document">
                                                            <div class="modal-content">
                                                                <div class="modal-header">
                                                                    <h5 class="modal-title" id="exampleModalLongTitle">
                                                                        مشاهدة الفيديو</h5>
                                                                    <button type="button" class="close"
                                                                            data-dismiss="modal" aria-label="Close">
                                                                        <span aria-hidden="true">&times;</span>
                                                                    </button>
                                                                </div>
                                                                <div class="modal-body text-center">
                                                                    <?php if(isset($video->file->file)): ?>
                                                                        <video width="420" height="340" controls>
                                                                            <source src="<?php echo e(asset('pictures/video/' . $video->file->file)); ?>">
                                                                        </video>
                                                                    <?php endif; ?>
                                                                    <?php if($video->file->link): ?>
                                                                            <?php
                                                                            $string     =  $video->file->link ;
                                                                            $search     = '/youtube\.com\/watch\?v=([a-zA-Z0-9]+)/smi';
                                                                            $replace    = "youtube.com/embed/$1";
                                                                            $url = preg_replace($search,$replace,$string);
                                                                            ?>
                                                                        <iframe style="width: 100%"
                                                                                src='<?php echo e($url); ?>?modestbranding=1'
                                                                                allowfullscreen>
                                                                        </iframe>
                                                                    <?php endif; ?>
                                                                </div>
                                                                <div class="modal-footer">
                                                                    <button type="button" class="btn btn-secondary"
                                                                            data-dismiss="modal">اغلاق
                                                                    </button>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- ens tabs  -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('frontend-footer'); ?>
    <script src="https://cdn.datatables.net/1.10.21/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.10.21/js/dataTables.bootstrap4.min.js"></script>
    <script>
        $(document).ready(function () {
            $('#example').DataTable({
                "language": {
                    "url": "<?php echo e(asset('frontend/js/ar_table.json')); ?>"
                }
            });
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH H:\laravel blogs\shobohat\resources\views/frontend/video/videos.blade.php ENDPATH**/ ?>