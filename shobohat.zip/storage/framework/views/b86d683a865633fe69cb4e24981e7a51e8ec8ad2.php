<?php $__env->startSection('frontend-head'); ?>
    <style>

        a {
            color: #c40030;
            background-color: transparent;
            -webkit-text-decoration-skip: objects;
        }
        .v-card {
            text-decoration: none;
        }

        .v-card > :first-child:not(.v-btn):not(.v-chip) {
            border-top-left-radius: inherit;
            border-top-right-radius: inherit;
        }

        .v-card > :last-child:not(.v-btn):not(.v-chip) {
            border-bottom-left-radius: inherit;
            border-bottom-right-radius: inherit;
        }

        .v-sheet {
            display: block;
            border-radius: 2px;
            position: relative;
        }
        .elevation-2 {
            box-shadow: 0 3px 1px -2px rgba(0, 0, 0, 0.2), 0 2px 2px 0 rgba(0, 0, 0, 0.14),
            0 1px 5px 0 rgba(0, 0, 0, 0.12) !important;
        }
        .title {
            font-size: 20px !important;
            font-weight: 700;
            line-height: 1 !important;
            letter-spacing: 0.02em !important;
        }

        .caption {
            font-weight: 400;
            font-size: 12px !important;
        }

        .theme--light.v-btn {
            color: rgba(0, 0, 0, 0.87);
        }

        .theme--light.v-btn:not(.v-btn--icon):not(.v-btn--flat) {
            background-color: #f5f5f5;
        }

        .theme--light .v-card {
            box-shadow: rgba(0, 0, 0, 0.11) 0 15px 30px 0px,
            rgba(0, 0, 0, 0.08) 0 5px 15px 0 !important;
        }

        .theme--light.application .v-card {
            box-shadow: 0 15px 30px 0 rgba(0, 0, 0, 0.11),
            0 5px 15px 0 rgba(0, 0, 0, 0.08) !important;
            color: #102c3c !important;
        }

        .theme--light.v-card,
        .theme--light.v-sheet {
            border-radius: 10px;
            background-color: #fff;
            border-color: #fff;
            color: rgba(0, 0, 0, 0.87);
        }

        a,
        a:hover {
            text-decoration: none !important;
        }

        .wrapper {
            overflow: auto;
        }

        .answers {
            padding-left: 64px;
        }

        .comment {
            overflow-y: auto;
            margin-left: 32px;
            margin-right: 16px;
        }

        .comment p {
            font-size: 14px;
            margin-bottom: 7px;
        }

        .displayName {
            margin-left: 24px;
        }

        .actions {
            display: flex;
            flex: 1;
            flex-direction: row;
            justify-content: flex-end;
        }

        .google-span[data-v-35838f51] {
            font-size: 14px;
            color: rgba(0, 0, 0, 0.54);
        }

        .google-button[data-v-35838f51] {
            background-color: #fff;
            height: 40px;
            margin: 0;
        }

        .headline {
            margin-left: 32px;
        }

        .sign-in-wrapper {
            margin-top: 16px;
            margin-left: 32px;
        }


        .error-message {
            font-style: oblique;
            color: #c40030;
        }

        ::-moz-selection,
        ::selection {
            background-color: #b3d4fc;
            color: #000;
            text-shadow: none;
        }

        .card,
        .card {
            padding: 32px 16px;
            margin-bottom: 32px;
            display: flex;
            flex-direction: column;
        }

        .application a,
        [type="button"],
        button {
            cursor: pointer;
        }

        @media  screen and (max-width: 640px) {
            .comment-container {
                width: 100%;
            }
            .comments {
                padding: 20px;
            }
        }
    </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('pageTitle', $question->mini_question); ?>
<?php $__env->startSection('frontend-main'); ?>
    <div class="print-image text-center mb-3">
        <img src="<?php echo e(asset('frontend/img/222.png')); ?>">
    </div>
    <div class="total-artical">
        <div class="sobts">
            <div class="shobohat mb-5">
                <div class="container">
                    <div class="allshobohat">
                        <div class="title">
                            <h4 class="titleshop mt-5 mb-5">
                                <?php echo e($question->mini_question); ?>

                            </h4>
                        </div>
                        <div class="download-share d-colm">
                            <div class="row download-sharebox">
                                <div class="col-md-2 numbs minimartop d-colmm">
                                    <i class="fas fa-stream"></i>
                                    <?php echo e($question->id); ?>

                                </div>
                                <div class="vl"></div>
                                <div class="col-md-3 time-date minimartop d-colmm">
                                    تاريخ النشر : <?php echo e($question->answered_date); ?>

                                </div>
                                <div class="vl"></div>
                                <div class="col-md-6 views d-colm minimartop d-centerr">
                                    المشاهدات : <?php echo e($question->views); ?>

                                    <div class="icondownlod minimartop">
                                        <a style="cursor: pointer" type="button" data-toggle="modal" data-target="#share">
                                            <i class="fas fa-share-alt"></i>
                                        </a>
                                        <button style="font-size:inherit" class="btn p-0 m-0 mt-1" onclick="display()">
                                            <i class="fas fa-print"></i>
                                        </button>
                                        <a href="#"></a>
                                        <a href="<?php echo e(route('question_pdf', $question->id )); ?>"><i class="fas fa-download"></i></a>
                                    </div>
                                </div>
                            </div>
                            <div class="mainques">
                                <h4>السؤال</h4>
                                <p>
                                    <?php echo e($question->question); ?>

                                </p>
                            </div>
                            <?php if(!empty($question->mini_answer)): ?>
                                <div class="cutans">
                                    <h4>ملخص الجواب</h4>
                                    <p>
                                        <?php echo e($question->mini_answer); ?>

                                    </p>
                                </div>
                            <?php endif; ?>
                            <div class="textans">
                                <h4>نص الجواب</h4>
                                <?php if(count($question->answers) > 1): ?>
                                    <a class="btn anaser mb-3" data-toggle="collapse" href="#collapseExample"
                                       role="button"
                                       aria-expanded="false" aria-controls="collapseExample">
                                        <i class="far fa-clone"></i>
                                        العناصر
                                    </a>
                                    <div class="collapse show" id="collapseExample">
                                        <div class="card card-body">
                                            <?php $__currentLoopData = $question->answers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $answer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <p><?php echo e($answer->title); ?></p>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </div>
                                    </div>
                                <?php endif; ?>
                                <p>الحمد لله</p>
                                <?php $__currentLoopData = $question->answers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $answer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <h4><?php echo e($answer->title); ?></h4>
                                    <p><?php echo htmlspecialchars_decode($answer->answer) ?></p>
                                    <?php if(!$loop->last): ?>
                                        <hr/>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                            <?php if(!empty($question->file->file) || isset($question->file->link)): ?>
                            <div class="textans video-que-section">
                                <h4>فيديو الشبهة</h4>
                                <?php if(!empty($question->file->file) || isset($question->file->link)): ?>
                                    <div class="col-md-12 col-12 mb-3 link">
                                        <div class="col-md-12 text-center">
                                            <?php if(isset($question->file->link)): ?>
                                                <?php
                                                $string     =  $question->file->link ;
                                                $search     = '/youtube\.com\/watch\?v=([a-zA-Z0-9]+)/smi';
                                                $replace    = "youtube.com/embed/$1";
                                                $url = preg_replace($search,$replace,$string);
                                                ?>
                                                <iframe width="420" height="315" src='<?php echo e($url); ?>?modestbranding=1' allowfullscreen>
                                                </iframe>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                    <div class="col-md-12 col-12 mb-3 file">
                                        <div class="col-md-12 text-center">
                                            <?php if(isset($question->file->file)): ?>
                                                <video poster="<?php echo e(asset('frontend/img/empty.png')); ?>" style="width: 100%" id="old" controls>
                                                    <source src="<?php echo e(asset('pictures/video/' . $question->file->file)); ?>">
                                                </video>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                <?php endif; ?>
                            </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="shobohat mb-5">
        <div class="container">
            <div class="allshobohat">
                <div class="title">
                    <h4 class="titleshop mt-5 mb-5">
                        التعليقات
                    </h4>
                </div>
            </div>
        </div>
    </div>
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <?php if(count($question->comments) > 0): ?>
                <div class="comment-container theme--light">
                    <div class="comments">
                        <?php $__currentLoopData = $question->comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div>
                                <div  class="card v-card v-sheet theme--light elevation-2">
                                    <div style="display: flex;justify-content: space-between;" class="header">
                                        <span  class="displayName title"><?php echo e($comment->user->name); ?></span>
                                        <span  class="displayName caption"><?php echo e($comment->created_at->diffForHumans()); ?></span>
                                    </div>
                                    <br>
                                    <div  class="wrapper comment">
                                        <p>
                                            <?php echo e($comment->comment); ?>

                                        </p>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
                <?php else: ?>
                    <div class="alert alert-warning">
                        <h3>
                            لم يتم اضافة تعليقات بعد ....
                        </h3>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
    <div class="resource">
        <div class="container">
            <div class="resourceall">
                <div class="restext">
                    <?php if(!empty($question->sources)): ?>
                        <p>
                            <span>المصدر : </span>
                            <?php echo htmlspecialchars_decode($question->sources) ?>
                        </p>
                    <?php endif; ?>
                </div>
                <div class="restext">
                    <!-- Button trigger modal -->
                    <?php if(auth()->guard()->check()): ?>
                        <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModal">
                            اضف تعليقا
                        </button>
                    <?php else: ?>
                        <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#like">
                            اضف تعليقا
                        </button>
                    <?php endif; ?>
                <!-- Modal -->
                    <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel"
                         aria-hidden="true">
                        <div class="modal-dialog">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title" id="exampleModalLabel">اضف تعليقك</h5>
                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                </div>
                                <div class="modal-body">
                                    <div class="form-group">
                                        <label for="comment_body">التعليق</label>
                                        <textarea name="comment" class="form-control" id="comment_body"
                                                  rows="3"></textarea>
                                    </div>
                                    <button onclick="return false;" ad="<?php echo e($question->id); ?>"
                                            data-token="<?php echo e(csrf_token()); ?>" type="submit" class="btn btn-secondary sub"
                                            data-dismiss="modal">حفظ
                                    </button>
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-secondary" data-dismiss="modal">اغلاق</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- share modale -->
    <div class="modal fade" id="share" tabindex="-1" role="dialog" aria-labelledby="share_title" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title text-primary" id="share_title">مشاركة الشبهة</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <?php $actual_link = "http://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]"; ?>
                    <ul>
                        <li title="مشاركة على فيس بوك">
                            <a href="https://www.facebook.com/sharer/sharer.php?u=<?= $actual_link; ?>" target="_blank">
                                <img src="<?php echo e(asset('frontend/img/facebook.png')); ?>">
                            </a>
                        </li>
                        <li title="مشاركة على تويتر">
                            <a href="http://twitter.com/home?status=<?php echo e($question->mini_question); ?>+<?= $actual_link; ?>"
                               target="_blank">
                                <img src="<?php echo e(asset('frontend/img/twitter.png')); ?>">
                            </a>
                        </li>
                        <li title="مشاركة على الواتس اب">
                            <a href="https://api.whatsapp.com://send?text=<?= $actual_link; ?>" target="_blank" title="Share on whatsapp">
                                <img src="<?php echo e(asset('frontend/img/whatsapp.png')); ?>">
                            </a>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('frontend-footer'); ?>
    <script>
        function display() {
            window.print();
        }
    </script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@9"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH H:\laravel blogs\shobohat\resources\views/frontend/question/question_single.blade.php ENDPATH**/ ?>