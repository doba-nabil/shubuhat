<div id="Tokyo" class="tabcontent">
    <!-- now shobohat  -->
    <div class="sobts">
        <div class="shobohat mb-5">
            <div class="">
                <div class="allshobohat">
                    <!-- search  -->
                    <div class="search">
                        <div class="">
                            <div class="allsea">
                            </div>
                        </div>
                    </div>
                    <!-- end search  -->
                    <div class="totaltotal">
                        <?php if(count($like_questions) > 0): ?>
                        <table class="table example table-borderless" style="width:100%">
                            <thead style="display:none;">
                            <tr>
                                <th hidden></th>
                                <th></th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $like_questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td hidden></td>
                                    <td>
                                        <div class="totalshob">
                                            <div class="oneshob d-colm">

                                                <div class="rightshob d-colm">
                                                    <?php
                                                    $likee = \App\Models\Favourite::where('question_id', $question->id)->where('user_id', $user->id)->count();
                                                    ?>
                                                    <?php if($likee > 0): ?>
                                                        <a role="button" class="favourite_add color"
                                                           ad="<?php echo e($question->id); ?>" data-token="<?php echo e(csrf_token()); ?>">
                                                            <i class="far fa-bookmark"></i>
                                                        </a>
                                                    <?php else: ?>
                                                        <a role="button" class="favourite_add" ad="<?php echo e($question->id); ?>"
                                                           data-token="<?php echo e(csrf_token()); ?>">
                                                            <i class="far fa-bookmark"></i>
                                                        </a>
                                                    <?php endif; ?>
                                                    <a href="<?php echo e(route('question.show' , $question->slug)); ?>">
                                                        <p class="d-center">
                                                            <?php echo e($question->mini_question); ?>

                                                        </p>
                                                    </a>
                                                </div>
                                                <div class="leftshob pigmartop">
                                                    <a href="<?php echo e(route('question.show' , $question->slug)); ?>">
                                                        <p class="pigmartop">
                                                            <?php echo e(Carbon\Carbon::parse($question->answered_date)->format('d-m-Y')); ?>

                                                        </p>
                                                    </a>
                                                </div>
                                            </div>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                        <?php else: ?>
                            <br>
                            <div class="alert alert-warning">
                                <h3>
                                    لا يوجد شبهات في المفضلة ....
                                </h3>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- now shobohat  -->
</div><?php /**PATH /home/nej76515k7il/public_html/resources/views/frontend/profile/content_sections/favourite.blade.php ENDPATH**/ ?>