<?php if(count($errors)>0): ?>
    <div class="alert alert-danger text-center">
        <i class="far fa-times-circle fa-3x mt-3"></i>
    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <p class="text-danger mt-3"><?php echo e($error); ?></p>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
<?php endif; ?><?php /**PATH H:\laravel blogs\shobohat\resources\views/common/errors_frontend.blade.php ENDPATH**/ ?>