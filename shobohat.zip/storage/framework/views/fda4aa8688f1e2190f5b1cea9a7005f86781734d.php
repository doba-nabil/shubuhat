<?php $__env->startSection('pageTitle', 'المقالات'); ?>
<?php $__env->startSection('frontend-main'); ?>
    <!-- tabs  -->
    <div class="tabs">
        <div class="container">
            <div class="title">
                <h4 class="sectiontitle mb-5">
                    الكتب
                </h4>
            </div>
            <div class="alltabs">
                <div class="content">
                    <div class="tab-content">
                        <div id="artical" class=" tab-pane active">
                            <table id="example" class="table  table-borderless">
                                <thead style="display:none;">
                                <tr>
                                    <th hidden></th>
                                    <th></th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php $__currentLoopData = $books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td hidden></td>
                                        <td>
                                            <div class="allvideo d-colm">
                                                <div class="rightsec d-colm">
                                                    <div class="secimg">
                                                        <?php if(isset($book->mainImage->image)): ?>
                                                            <img src="<?php echo e(asset('pictures/media/' . $book->mainImage->image)); ?>"
                                                                 alt="<?php echo e($book->title); ?>">
                                                        <?php else: ?>
                                                            <img src="<?php echo e(asset('frontend/img/empty.png')); ?>" alt=""/>
                                                        <?php endif; ?>

                                                    </div>
                                                    <div class="viddeta d-colm">
                                                        <p class="namev"><?php echo e($book->title); ?></p>
                                                        <p class="catv"><?php echo e($book->category->title ?? ''); ?></p>
                                                        <p class="timev"><?php echo e(Carbon\Carbon::parse($book->created_at)->format('d-m-Y')); ?></p>
                                                    </div>
                                                </div>
                                                <div class="leftsec d-colm">
                                                    <a class="pigmarbot" href="<?php echo e(route('book.show' , $book->slug)); ?>">
                                                        <button type="button" class="btn shahed">
                                                            نبذة
                                                        </button>
                                                    </a>
                                                    <a class="pigmarbot" href="<?php echo e(asset('pictures/books/' . $book->file->file)); ?>"
                                                    target="_blank">
                                                        <button type="button" class="btn shahed">
                                                            تصفح
                                                        </button>
                                                    </a>
                                                    <button type="button" class="btn shahed-dwon">
                                                        <a target="_blank"
                                                           href="<?php echo e(asset('pictures/books/' . $book->file->file)); ?>"
                                                           download="">
                                                            تحميل
                                                            <i class="fa fa-download"></i>
                                                        </a>
                                                    </button>
                                                </div>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- ens tabs  -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('frontend-footer'); ?>
    <script src="https://cdn.datatables.net/1.10.21/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.10.21/js/dataTables.bootstrap4.min.js"></script>
    <script>
        $(document).ready(function () {
            $('#example').DataTable({
                "language": {
                    "url": "<?php echo e(asset('frontend/js/ar_table.json')); ?>"
                }
            });
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/nej76515k7il/public_html/resources/views/frontend/book/books.blade.php ENDPATH**/ ?>