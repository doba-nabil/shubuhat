<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html dir="rtl" lang="ar">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
    <style>
         body, *{
            direction: rtl;
             font-family: DejaVu Sans, sans-serif;
             text-align: right;
        }
        body{
            background-color: #F6FAFB;
        }
        .total-artical{
            border: 3px solid #4699B7;
            border-radius: 5px;
            padding: 0px 20px;
        }
        @page{
            size:A4;
            text-align:center;
        }
        @page  p{
            margin-right:0px;
            text-align:center;
        }
    </style>
    <title>الشبهات سؤال وجواب</title>
</head>
<body>
<div class="total-artical">
    <div class="sobts">
        <div class="shobohat mb-5">
            <div class="container">
                <div class="allshobohat">
                    <div class="download-share d-colm">
                        <div class="textans textansmine">
                            <p> ملخص السؤال :  <?php echo e($question->mini_question); ?></p>
                            <br>
                            <p>  السؤال   <?php echo e($question->question); ?> :</p>
                            <hr>
                            <p>الحمد لله</p>
                            <?php if(!empty($question->mini_answer)): ?>
                                <div class="cutans">
                                    <p>ملخص الجواب</p>
                                    <p>
                                        <?php echo e($question->mini_answer); ?>

                                    </p>
                                </div>
                            <?php endif; ?>
                            <p>نص الجواب</p>
                            <?php if(count($question->answers) > 1): ?>
                                <a class="btn anaser mb-3" data-toggle="collapse" href="#collapseExample"
                                   role="button"
                                   aria-expanded="false" aria-controls="collapseExample">
                                    <i class="far fa-clone"></i>
                                    العناصر
                                </a>
                              
                                    <p class="card card-body">
                                        <?php $__currentLoopData = $question->answers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $answer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <p><?php echo e($answer->title); ?></p>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </p>
                                
                            <?php endif; ?>
                            <hr style="width: 50%">
                            <?php $__currentLoopData = $question->answers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $answer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <p><?php echo e($answer->title); ?></p>
                                <p><?php echo e($answer->answer); ?></p>
                                <?php if(!$loop->last): ?>
                                    <hr/>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
</body>
</html><?php /**PATH /home/nej76515k7il/public_html/resources/views/frontend/question/question_pdf.blade.php ENDPATH**/ ?>