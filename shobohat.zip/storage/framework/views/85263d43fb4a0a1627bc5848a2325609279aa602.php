<?php $__env->startSection('pageTitle', 'المقالات'); ?>
<?php $__env->startSection('frontend-main'); ?>
    <!-- now shobohat  -->
    <div class="sobts">
        <div class="shobohat mb-5">
            <div class="container">
                <div class="allshobohat">
                    <div class="title">
                        <h4 class="titleshop mt-4 mb-5">
                            نتائج البحث عن <?php echo e($keyword); ?>

                        </h4>
                    </div>
                    <!-- search  -->
                    <div class="search">
                        <div class="">
                            <div class="allsea">
                                <form style="width: 100%" method="post" action="<?php echo e(route('catSearch')); ?>">
                                    <?php echo csrf_field(); ?>
                                    <div class="search">
                                        <div class="allsea">
                                            <input name="word" class="form-control" type="text" placeholder=" إبحث عن شبهات عن طريق الشبهة او رقمها">
                                            <button type="submit"><i class="fas fa-search"></i></button>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                    <!-- end search  -->
                    <div class="totaltotal">
                        <?php if(count($questions) > 0): ?>
                        <?php $__currentLoopData = $questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="totalshob">

                                            <div class="oneshob d-colm">
                                                <div class="rightshob d-colm">
                                                    <?php if(auth()->guard()->check()): ?>
                                                        <?php
                                                        $likee = \App\Models\Favourite::where('question_id', $question->id)->where('user_id', Auth::user()->id)->count();
                                                        ?>
                                                        <?php if($likee > 0): ?>
                                                            <a role="button" class="favourite_add color"
                                                               ad="<?php echo e($question->id); ?>" data-token="<?php echo e(csrf_token()); ?>">
                                                                <i class="far fa-bookmark"></i>
                                                            </a>
                                                        <?php else: ?>
                                                            <a role="button" class="favourite_add"
                                                               ad="<?php echo e($question->id); ?>"
                                                               data-token="<?php echo e(csrf_token()); ?>">
                                                                <i class="far fa-bookmark"></i>
                                                            </a>
                                                        <?php endif; ?>
                                                    <?php else: ?>
                                                        <button type="button" class="btn" data-toggle="modal"
                                                                data-target="#like">
                                                            <i class="far fa-bookmark"></i>
                                                        </button>
                                                    <?php endif; ?>
                                                    <a href="<?php echo e(route('question.show' , $question->slug)); ?>">
                                                        <p class="d-center">
                                                            <?php echo e($question->mini_question); ?>

                                                        </p>
                                                    </a>
                                                </div>
                                                <div class="leftshob pigmartop">
                                                    <a href="<?php echo e(route('question.show' , $question->slug)); ?>">
                                                        <p class="pigmartop">
                                                            <?php echo e(Carbon\Carbon::parse($question->answered_date)->format('d-m-Y')); ?>

                                                        </p>
                                                    </a>
                                                </div>
                                            </div>

                                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>
                            <div class="alert alert-warning">
                                <h3>لم يتم العثور على اي شبهات </h3>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- now shobohat  -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('frontend-footer'); ?>
    <script src="https://cdn.datatables.net/1.10.21/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.10.21/js/dataTables.bootstrap4.min.js"></script>
    <script>
        $(document).ready(function () {
            $('#example').DataTable({
                "language": {
                    "url": "<?php echo e(asset('frontend/js/ar_table.json')); ?>"
                }
            });
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/nej76515k7il/public_html/resources/views/frontend/question_search.blade.php ENDPATH**/ ?>