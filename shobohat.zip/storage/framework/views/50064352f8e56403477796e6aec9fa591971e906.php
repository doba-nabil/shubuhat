<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimal-ui">
<meta name="description" content="shobohat , doba , dobanabil">
<meta name="keywords" content="shobohat , doba dashboard">
<meta name="author" content="PIXINVENT">
<title>لوحة تحكم موقع الشبهات</title>
<link rel="icon" href="<?php echo e(asset('backend')); ?>/app-assets/images/pages/i-icon.png">
<link href="https://fonts.googleapis.com/css2?family=Changa:wght@300&display=swap" rel="stylesheet">
<?php $__env->startSection('backend-head'); ?>
<?php echo $__env->yieldSection(); ?>
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('backend')); ?>/app-assets/vendors/css/animate/animate.css">
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('backend')); ?>/app-assets/vendors/css/extensions/sweetalert2.min.css">

<link rel="stylesheet" href="<?php echo e(asset('backend')); ?>/mine.css">
<?php /**PATH /home/nej76515k7il/public_html/resources/views/backend/layout/head.blade.php ENDPATH**/ ?>