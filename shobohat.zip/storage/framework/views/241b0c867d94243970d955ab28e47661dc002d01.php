<!DOCTYPE html>
<html lang="ar">
<head>
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <?php echo $__env->make('frontend.layout.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <title><?php echo e($option->title); ?> - <?php echo $__env->yieldContent('pageTitle'); ?></title>
</head>
<body>
<!-- end navbar  -->
<?php echo $__env->make('frontend.layout.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<input type="hidden" value="<?php echo e(URL::to('/')); ?>" id="base_url">
<?php $__env->startSection('frontend-main'); ?>

<?php echo $__env->yieldSection(); ?>
<?php if(auth()->guard()->guest()): ?>
    <!-- login to like Modal -->
    <div class="modal fade" id="like" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-body text-center">
                    <i class="fas fa-exclamation-triangle fa-8x mb-4"></i>
                    <h3 class="text-danger mb-4">
                        يرجى التسجيل اولا لاضافة
                        <?php echo e(Request::is('question*')? 'تعليق....': 'الشبهة الى المفضلة....'); ?>

                    </h3>
                </div>
            </div>
        </div>
    </div>
    
<?php endif; ?>

<?php echo $__env->make('frontend.layout.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>
</html><?php /**PATH /home/nej76515k7il/public_html/resources/views/frontend/layout/master.blade.php ENDPATH**/ ?>