<?php if(session()->has('done')): ?>
    <div class="alert alert-success text-center">
        <i class="far fa-check-circle fa-3x mt-3"></i>
        <p class="text-success mt-3"><?php echo e(session()->get('done')); ?></p>
    </div>
<?php endif; ?>
<?php if(session()->has('error')): ?>
    <div class="alert alert-danger text-center">
        <i class="far fa-times-circle fa-3x mt-3"></i>
        <p class="text-danger mt-3"><?php echo e(session()->get('error')); ?></p>
    </div>
<?php endif; ?>

<?php /**PATH /home/nej76515k7il/public_html/resources/views/common/done_frontend.blade.php ENDPATH**/ ?>