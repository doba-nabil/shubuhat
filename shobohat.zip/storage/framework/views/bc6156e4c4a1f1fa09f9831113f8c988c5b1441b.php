<?php $__env->startSection('pageTitle', $question->mini_question); ?>
<?php $__env->startSection('frontend-main'); ?>
    <div class="print-image text-center mb-3">
        <img src="<?php echo e(asset('frontend/img/222.png')); ?>">
    </div>
    <div class="total-artical">
        <div class="sobts">
            <div class="shobohat mb-5">
                <div class="container">
                    <div class="allshobohat">
                        <div class="title">
                            <h4 class="titleshop mt-5 mb-5">
                                <?php echo e($question->mini_question); ?>

                            </h4>
                        </div>
                        <div class="download-share d-colm">
                            <div class="row download-sharebox">
                                <div class="col-md-2 numbs minimartop d-colmm">
                                    <i class="fas fa-stream"></i>
                                    <?php echo e($question->id); ?>

                                </div>
                                <div class="vl"></div>
                                <div class="col-md-3 time-date minimartop d-colmm">
                                    تاريخ النشر : <?php echo e($question->answered_date); ?>

                                </div>
                                <div class="vl"></div>
                                <div class="col-md-6 views d-colm minimartop d-centerr">
                                    المشاهدات : <?php echo e($question->views); ?>

                                    <div class="icondownlod minimartop">
                                        <a style="cursor: pointer" type="button" data-toggle="modal" data-target="#share">
                                            <i class="fas fa-share-alt"></i>
                                        </a>
                                        <button style="font-size:inherit" class="btn p-0 m-0 mt-1" onclick="display()">
                                            <i class="fas fa-print"></i>
                                        </button>
                                        <a href="#"></a>
                                        <a href="<?php echo e(route('question_pdf', $question->id )); ?>"><i class="fas fa-download"></i></a>
                                    </div>
                                </div>
                            </div>
                            <div class="mainques">
                                <h4>السؤال</h4>
                                <p>
                                    <?php echo e($question->question); ?>

                                </p>
                            </div>
                            <?php if(!empty($question->mini_answer)): ?>
                                <div class="cutans">
                                    <h4>ملخص الجواب</h4>
                                    <p>
                                        <?php echo e($question->mini_answer); ?>

                                    </p>
                                </div>
                            <?php endif; ?>
                            <div class="textans">
                                <h4>نص الجواب</h4>
                                <?php if(count($question->answers) > 1): ?>
                                    <a class="btn anaser mb-3" data-toggle="collapse" href="#collapseExample"
                                       role="button"
                                       aria-expanded="false" aria-controls="collapseExample">
                                        <i class="far fa-clone"></i>
                                        العناصر
                                    </a>
                                    <div class="collapse show" id="collapseExample">
                                        <div class="card card-body">
                                            <?php $__currentLoopData = $question->answers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $answer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <p><?php echo e($answer->title); ?></p>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </div>
                                    </div>
                                <?php endif; ?>
                                <p>الحمد لله</p>
                                <?php $__currentLoopData = $question->answers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $answer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <h4><?php echo e($answer->title); ?></h4>
                                    <p><?php echo e($answer->answer); ?></p>
                                    <?php if(!$loop->last): ?>
                                        <hr/>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                            <?php if(!empty($question->file->file) || isset($question->file->link)): ?>
                            <div class="textans video-que-section">
                                <h4>فيديو الشبهة</h4>
                                <?php if(!empty($question->file->file) || isset($question->file->link)): ?>
                                    <div class="col-md-12 col-12 mb-3 link">
                                        <div class="col-md-12 text-center">
                                            <?php if(isset($question->file->link)): ?>
                                                <?php
                                                $string     =  $question->file->link ;
                                                $search     = '/youtube\.com\/watch\?v=([a-zA-Z0-9]+)/smi';
                                                $replace    = "youtube.com/embed/$1";
                                                $url = preg_replace($search,$replace,$string);
                                                ?>
                                                <iframe width="420" height="315" src='<?php echo e($url); ?>?modestbranding=1' allowfullscreen>
                                                </iframe>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                    <div class="col-md-12 col-12 mb-3 file">
                                        <div class="col-md-12 text-center">
                                            <?php if(isset($question->file->file)): ?>
                                                <video poster="<?php echo e(asset('frontend/img/empty.png')); ?>" style="width: 100%" id="old" controls>
                                                    <source src="<?php echo e(asset('pictures/video/' . $question->file->file)); ?>">
                                                </video>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                <?php endif; ?>
                            </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="resource">
        <div class="container">
            <div class="resourceall">
                <div class="restext">
                    <?php if(!empty($question->sources)): ?>
                        <p>
                            <span>المصدر : </span>
                            <?php echo htmlspecialchars_decode($question->sources) ?>
                        </p>
                    <?php endif; ?>
                </div>
                <div class="restext">
                    <!-- Button trigger modal -->
                    <?php if(auth()->guard()->check()): ?>
                        <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModal">
                            اضف تعليقا
                        </button>
                    <?php else: ?>
                        <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#like">
                            اضف تعليقا
                        </button>
                    <?php endif; ?>
                <!-- Modal -->
                    <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel"
                         aria-hidden="true">
                        <div class="modal-dialog">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title" id="exampleModalLabel">اضف تعليقك</h5>
                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                </div>
                                <div class="modal-body">
                                    <div class="form-group">
                                        <label for="comment_body">التعليق</label>
                                        <textarea name="comment" class="form-control" id="comment_body"
                                                  rows="3"></textarea>
                                    </div>
                                    <button onclick="return false;" ad="<?php echo e($question->id); ?>"
                                            data-token="<?php echo e(csrf_token()); ?>" type="submit" class="btn btn-secondary sub"
                                            data-dismiss="modal">حفظ
                                    </button>
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-secondary" data-dismiss="modal">اغلاق</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- share modale -->
    <div class="modal fade" id="share" tabindex="-1" role="dialog" aria-labelledby="share_title" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title text-primary" id="share_title">مشاركة الشبهة</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <?php $actual_link = "http://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]"; ?>
                    <ul>
                        <li title="مشاركة على فيس بوك">
                            <a href="https://www.facebook.com/sharer/sharer.php?u=<?= $actual_link; ?>" target="_blank">
                                <img src="<?php echo e(asset('frontend/img/facebook.png')); ?>">
                            </a>
                        </li>
                        <li title="مشاركة على تويتر">
                            <a href="http://twitter.com/home?status=<?php echo e($question->mini_question); ?>+<?= $actual_link; ?>"
                               target="_blank">
                                <img src="<?php echo e(asset('frontend/img/twitter.png')); ?>">
                            </a>
                        </li>
                        <li title="مشاركة على الواتس اب">
                            <a href="https://api.whatsapp.com://send?text=<?= $actual_link; ?>" target="_blank" title="Share on whatsapp">
                                <img src="<?php echo e(asset('frontend/img/whatsapp.png')); ?>">
                            </a>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('frontend-footer'); ?>
    <script>
        function display() {
            window.print();
        }
    </script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@9"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/nej76515k7il/public_html/resources/views/frontend/question/question_single.blade.php ENDPATH**/ ?>