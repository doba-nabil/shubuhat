<?php $__env->startSection('frontend-head'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('pageTitle', 'اتصل بنا'); ?>
<?php $__env->startSection('frontend-main'); ?>
    <!--  callus  -->
    <div class="callus">
        <div class="aboutus">
            <div class="container">
                <div class="allaboutus">
                    <div class="title">
                        <h4 class="titleabout">
                            إتصل بنا
                        </h4>
                        <p class="cont">لا يمكن طرح الأسئلة من هذا النموذج</p>
                    </div>
                    <form method="post" action="<?php echo e(route('contact_form')); ?>" id="contact_form" class="formsty">
                        <?php echo csrf_field(); ?>
                        <div class="form-group">
                            <label for="name">الإسم</label>
                            <input name="name" type="text" class="form-control" id="name" placeholder="اسم الراسل">
                        </div>
                        <div class="form-group">
                            <label for="email">البريد الإلكترونى</label>
                            <input name="email" type="email" class="form-control" id="email" placeholder="بريد الراسل">
                        </div>
                        <div class="form-group ">
                            <label for="exampleFormControlSelect1">نوع الرسالة</label>
                            <select name="kind" class="form-control form-groupw" id="exampleFormControlSelect1" >
                                <option class="optiondis" value="" disabled selected hidden> أختر نوع الرسالة</option>
                                <option>اقتراحات</option>
                                <option>ملاحظة فنية</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="title">عنوان الرسالة</label>
                            <input name="title" type="text" class="form-control" id="title" placeholder=" أكتب عنواناً لرسالتك">
                        </div>
                        <div class="form-group">
                            <label for="message">الرسالة</label>
                            <textarea name="message" class="form-control" id="message" cols='3' rows="3" placeholder="اكتب نص الرسالة"></textarea>
                        </div>
                        <button class="btn btnformse">إرسال</button>
                    </form>

                </div>
            </div>
        </div>
    </div>
    <!-- end callus  -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('frontend-footer'); ?>
<script>
    $("#contact_form").validate({
        rules: {
            email: {
                required: true,
                email: true,
            },
            name: {
                required: true,
            },
            title: {
                required: true,
            },
            kind: {
                required: true,
            },
            message: {
                required: true,
            },
        },
        messages:{
            email: {
                required : 'هذا الحقل مطلوب',
                minlength : 'هذا الحقل مطلوب اقل من المسموح',
            },
            name: {
                required : 'هذا الحقل مطلوب',
            },
            title: {
                required : 'هذا الحقل مطلوب',
            },
            kind: {
                required : 'هذا الحقل مطلوب',
            },
            message: {
                required : 'هذا الحقل مطلوب',
            },
        }
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/nej76515k7il/public_html/resources/views/frontend/contact.blade.php ENDPATH**/ ?>