
<?php $__env->startSection('frontend-head'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('pageTitle', $folder->title); ?>
<?php $__env->startSection('frontend-main'); ?>
    <!-- search  -->
    <div class="searchcat">
        <div class="container">
            <div class="allsea">
                <h4><?php echo e($folder->title); ?></h4>
            </div>
        </div>
    </div>
    <!-- end search  -->
    <!-- now shobohat  -->
    <div class="catshobohat">
        <div class="shobohat">
            <div class="container">
                <div class="allshobohat">
                    <div class="title">
                        <h4 class="titleshop">
                            شبهات جديدة
                        </h4>
                        <a class="btn catbtn" href="<?php echo e(route('folder.index')); ?>">
                            عودة للملفات المتنوعة
                        </a>
                    </div>
                    <div style="width: 100%;" class="row rowrescat">
                        <div class="main-tab-content col-md-12">
                            <div style="width: 100%" class="totaltotal">
                                <?php if(count($questions) > 0): ?>
                                    <table class="table example  table-borderless" style="width:100%">
                                        <thead style="display:none;">
                                        <tr>
                                            <th hidden></th>
                                            <th></th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                        <?php $__currentLoopData = $questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td hidden></td>
                                                <td>
                                                    <div class="totalshob">

                                                        <div class="oneshob d-colm">
                                                            <div class="rightshob d-colm">
                                                                <?php if(auth()->guard()->check()): ?>
                                                                    <?php
                                                                    $likee = \App\Models\Favourite::where('question_id', $question->id)->where('user_id', Auth::user()->id)->count();
                                                                    ?>
                                                                    <?php if($likee > 0): ?>
                                                                        <a role="button" class="favourite_add color"
                                                                           ad="<?php echo e($question->id); ?>"
                                                                           data-token="<?php echo e(csrf_token()); ?>">
                                                                            <i class="far fa-bookmark"></i>
                                                                        </a>
                                                                    <?php else: ?>
                                                                        <a role="button" class="favourite_add"
                                                                           ad="<?php echo e($question->id); ?>"
                                                                           data-token="<?php echo e(csrf_token()); ?>">
                                                                            <i class="far fa-bookmark"></i>
                                                                        </a>
                                                                    <?php endif; ?>
                                                                <?php else: ?>
                                                                    <button type="button" class="btn"
                                                                            data-toggle="modal" data-target="#like">
                                                                        <i class="far fa-bookmark"></i>
                                                                    </button>
                                                                <?php endif; ?>
                                                                <a href="<?php echo e(route('question.show' , $question->slug)); ?>">
                                                                    <p class="d-center"><?php echo e($question->mini_question); ?></p>
                                                                </a>
                                                            </div>
                                                            <div class="leftshob pigmartop">
                                                                <a href="<?php echo e(route('question.show' , $question->slug)); ?>">
                                                                    <p class="pigmartop">
                                                                        <?php echo e(Carbon\Carbon::parse($question->answered_date)->format('d-m-Y')); ?>

                                                                    </p>
                                                                </a>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                <?php else: ?>
                                    <div class="alert alert-warning">
                                        <h3>
                                            لا يوجد شبهات في الملف....
                                        </h3>
                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- now shobohat  -->
    <!-- tabs  -->
    <div class="tabs">
        <div class="container">
            <div class="title">
                <h4 class="sectiontitle mb-5">
                    مكتبة الوسائط
                </h4>
            </div>
            <div class="alltabs">

                <div class="content">
                    <!-- Nav pills -->
                    <ul class="nav nav-pills" role="tablist">
                        <li class="nav-item">
                            <a class="nav-link active" data-toggle="pill" href="#vdio">
                                <i class="fas fa-video"></i>
                                فيديوهات</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" data-toggle="pill" href="#record">
                                <i class="fas fa-volume-down"></i>
                                صوتيات</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" data-toggle="pill" href="#book">
                                <i class="fas fa-book"></i>
                                كتب</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" data-toggle="pill" href="#artical">
                                <i class="far fa-newspaper"></i>
                                مقالات</a>
                        </li>
                    </ul>

                    <!-- Tab panes -->
                    <div class="tab-content">
                        <div id="vdio" class=" tab-pane active">
                            <?php if(count($videos) > 0): ?>
                                <table class="table example table-borderless" style="width:100%">
                                    <thead style="display:none;">
                                    <tr>
                                        <th hidden></th>
                                        <th></th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <?php $__currentLoopData = $videos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $video): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td hidden></td>
                                            <td>
                                                <div class="allvideo d-colm">
                                                    <div class="rightsec d-colm">
                                                        <div class="secimg d-center">
                                                            <?php if(isset($video->mainImage->image)): ?>
                                                                <img src="<?php echo e(asset('pictures/media/' . $video->mainImage->image) ?? '--'); ?>"
                                                                     alt="<?php echo e($video->title); ?>">
                                                            <?php else: ?>
                                                                <img src="<?php echo e(asset('frontend/img/empty.png')); ?>"
                                                                     alt=""/>
                                                            <?php endif; ?>
                                                            <div class="overlaysec"><i class="far fa-play-circle"></i>
                                                            </div>
                                                        </div>
                                                        <div class="viddeta d-colm">
                                                            <p class="namev"><?php echo e($video->title); ?></p>
                                                            <p class="catv"><?php echo e($video->category->title ?? ''); ?></p>
                                                            <p class="timev"><?php echo e(Carbon\Carbon::parse($video->created_at)->format('d-m-Y')); ?></p>
                                                        </div>
                                                    </div>
                                                    <div class="leftsec">
                                                        <!-- Button trigger modal -->
                                                        <button type="button" class="btn shahed" data-toggle="modal"
                                                                data-target="#video_modal<?php echo e($loop->index + 1); ?>">
                                                            مشاهدة
                                                        </button>
                                                        <!-- Modal -->
                                                        <div class="modal fade" id="video_modal<?php echo e($loop->index + 1); ?>"
                                                             tabindex="-1" role="dialog"
                                                             aria-labelledby="exampleModalCenterTitle"
                                                             aria-hidden="true">
                                                            <div class="modal-dialog modal-dialog-centered"
                                                                 role="document">
                                                                <div class="modal-content">
                                                                    <div class="modal-header">
                                                                        <h5 class="modal-title"
                                                                            id="exampleModalLongTitle">
                                                                            مشاهدة الفيديو</h5>
                                                                        <button type="button" class="close"
                                                                                data-dismiss="modal" aria-label="Close">
                                                                            <span aria-hidden="true">&times;</span>
                                                                        </button>
                                                                    </div>
                                                                    <div class="modal-body text-center">
                                                                        <?php if(isset($video->file->file)): ?>
                                                                            <video width="420" height="340" controls>
                                                                                <source src="<?php echo e(asset('pictures/video/' . $video->file->file)); ?>">
                                                                            </video>
                                                                        <?php endif; ?>
                                                                        <?php if($video->file->link): ?>
                                                                                <?php
                                                                                $string     =  $video->file->link ;
                                                                                $search     = '/youtube\.com\/watch\?v=([a-zA-Z0-9]+)/smi';
                                                                                $replace    = "youtube.com/embed/$1";
                                                                                $url = preg_replace($search,$replace,$string);
                                                                                ?>
                                                                            <iframe style="width: 100%"
                                                                                    src='<?php echo e($url); ?>?modestbranding=1'
                                                                                    allowfullscreen>
                                                                            </iframe>
                                                                        <?php endif; ?>
                                                                    </div>
                                                                    <div class="modal-footer">
                                                                        <button type="button" class="btn btn-secondary"
                                                                                data-dismiss="modal">اغلاق
                                                                        </button>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            <?php else: ?>
                                <div class="alert alert-warning">
                                    <h3>
                                        لا يوجد فيديوهات في الملف....
                                    </h3>
                                </div>
                            <?php endif; ?>
                        </div>
                        <div id="record" class=" tab-pane fade">
                            <?php if(count($audios)): ?>
                                <table class="table example table-borderless" style="width:100%">
                                    <thead style="display:none;">
                                    <tr>
                                        <th hidden></th>
                                        <th></th>
                                    </tr>
                                    </thead>
                                    <tbody>

                                    <?php $__currentLoopData = $audios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $audio): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td hidden></td>
                                            <td>
                                                <div class="allaudio <?php if(empty($audio->file->file)): ?> allvideo <?php endif; ?>">
                                                    <h4 <?php if(empty($audio->file->file)): ?> class="text-center" <?php endif; ?>>
                                                        <?php echo e($audio->title); ?>

                                                        <?php if(empty($audio->file->file)): ?>
                                                            <img class="" width="120px"
                                                                 src="<?php echo e(asset('frontend/img/sound.png')); ?>">
                                                        <?php endif; ?>
                                                    </h4>
                                                    <p class="adiotext"><?php echo e($audio->subtitle); ?></p>
                                                    <?php if(!empty($audio->file->file)): ?>
                                                        <div class="ready-player-<?php echo e($audio->id); ?>">
                                                            <audio>
                                                                <source src="<?php echo e(asset('pictures/audio/' . $audio->file->file)); ?>">
                                                            </audio>
                                                        </div>
                                                    <?php else: ?>
                                                        <div class="modal fade"
                                                             id="exampleModalCenter<?php echo e($audio->slug); ?>"
                                                             tabindex="-1" role="dialog"
                                                             aria-labelledby="exampleModalCenterTitle"
                                                             aria-hidden="true">
                                                            <div class="modal-dialog modal-dialog-centered"
                                                                 role="document">
                                                                <div class="modal-content">
                                                                    <div class="modal-header">
                                                                        <h5 class="modal-title"
                                                                            id="exampleModalLongTitle"><?php echo e($audio->title); ?></h5>
                                                                        <button type="button" class="close"
                                                                                data-dismiss="modal"
                                                                                aria-label="Close">
                                                                            <span aria-hidden="true">&times;</span>
                                                                        </button>
                                                                    </div>
                                                                    <div class="modal-body text-center">
                                                                        <div>
                                                                            <?php echo $audio->file->link; ?>

                                                                            <div class="clearfix"></div>
                                                                        </div>
                                                                    </div>
                                                                    <div class="modal-footer">
                                                                        <button type="button" class="btn btn-secondary"
                                                                                data-dismiss="modal">اغلاق
                                                                        </button>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="leftsec">
                                                            <!-- Button trigger modal -->
                                                            <button type="button" class="btn shahed" data-toggle="modal"
                                                                    data-target="#exampleModalCenter<?php echo e($audio->slug); ?>">
                                                                استماع
                                                            </button>
                                                        </div>
                                                    <?php endif; ?>
                                                </div>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            <?php else: ?>
                                <div class="alert alert-warning">
                                    <h3>
                                        لا يوجد صوتيات في الملف....
                                    </h3>
                                </div>
                            <?php endif; ?>
                        </div>
                        <div id="book" class=" tab-pane fade">
                            <?php if(count($books) > 0): ?>
                                <table class="table example table-borderless">
                                    <thead style="display:none;">
                                    <tr>
                                        <th hidden></th>
                                        <th></th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <?php $__currentLoopData = $books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td hidden></td>
                                            <td>
                                                <div class="allvideo d-colm">
                                                    <div class="rightsec d-colm">
                                                        <div class="secimg">
                                                            <?php if(isset($book->mainImage->image)): ?>
                                                                <img src="<?php echo e(asset('pictures/media/' . $book->mainImage->image)); ?>"
                                                                     alt="<?php echo e($book->title); ?>">
                                                            <?php else: ?>
                                                                <img src="<?php echo e(asset('frontend/img/empty.png')); ?>"
                                                                     alt=""/>
                                                            <?php endif; ?>
                                                        </div>
                                                        <div class="viddeta d-colm">
                                                            <p class="namev"><?php echo e($book->title); ?></p>
                                                            <p class="catv"><?php echo e($book->category->title ?? ''); ?></p>
                                                            <p class="timev"><?php echo e(Carbon\Carbon::parse($book->created_at)->format('d-m-Y')); ?></p>
                                                        </div>
                                                    </div>
                                                    <div class="leftsec d-colm">
                                                        <a class="pigmarbot" href="<?php echo e(route('book.show' , $book->slug)); ?>">
                                                            <button type="button" class="btn shahed">
                                                                نبذة
                                                            </button>
                                                        </a>
                                                        <a class="pigmarbot" href="<?php echo e(asset('pictures/books/' . $book->file->file)); ?>"
                                                           target="_blank">
                                                            <button type="button" class="btn shahed">
                                                                تصفح
                                                            </button>
                                                        </a>
                                                        <a href="#">
                                                            <button type="button" class="btn shahed-dwon">
                                                                <a target="_blank"
                                                                   href="<?php echo e(asset('pictures/books/' . $book->file->file)); ?>"
                                                                   download="">
                                                                    تحميل
                                                                    <i class="fa fa-download"></i>
                                                                </a>
                                                            </button>
                                                        </a>
                                                    </div>
                                                </div>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            <?php else: ?>
                                <div class="alert alert-warning">
                                    <h3>
                                        لا يوجد كتب في الملف....
                                    </h3>
                                </div>
                            <?php endif; ?>
                        </div>
                        <div id="artical" class=" tab-pane fade">
                            <?php if(count($articles) > 0): ?>
                                <table class="table example table-borderless">
                                    <thead style="display:none;">
                                    <tr>
                                        <th hidden></th>
                                        <th></th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <?php $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td hidden></td>
                                            <td>
                                                <div class="allvideo d-colm">
                                                    <div class="rightsec d-colm">
                                                        <div class="secimg">
                                                            <?php if(isset($article->mainImage->image)): ?>
                                                                <img src="<?php echo e(asset('pictures/media/' . $article->mainImage->image)); ?>"
                                                                     alt="<?php echo e($article->title); ?>">
                                                            <?php else: ?>
                                                                <img src="<?php echo e(asset('frontend/img/empty.png')); ?>"
                                                                     alt=""/>
                                                            <?php endif; ?>
                                                        </div>
                                                        <div class="viddeta d-colm">
                                                            <p class="namev"><?php echo e($article->title); ?></p>
                                                            <p class="catv"><?php echo e($article->category->title); ?></p>
                                                            <p class="timev"><?php echo e(Carbon\Carbon::parse($article->created_at)->format('d-m-Y')); ?></p>
                                                        </div>
                                                    </div>
                                                    <div class="leftsec">
                                                        <a href="<?php echo e(route('article.show' , $article->slug)); ?>"
                                                           type="button" class="btn shahed">
                                                            تصفح
                                                        </a>
                                                    </div>
                                                </div>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            <?php else: ?>
                                <div class="alert alert-warning">
                                    <h3>
                                        لا يوجد مقالات في الملف....
                                    </h3>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div>
    <!-- ens tabs  -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('frontend-footer'); ?>
    <script src="<?php echo e(asset('frontend/js/javascript.js')); ?>"></script>
    <?php $__currentLoopData = $audios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $audio): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if(!empty($audio->file->file)): ?>
            <script>
                document.addEventListener('DOMContentLoaded', function () {
                    new GreenAudioPlayer('.ready-player-<?php echo e($audio->id); ?>', {
                        showTooltips: true,
                        showDownloadButton: false,
                        enableKeystrokes: true
                    });
                });
            </script>
        <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/nej76515k7il/public_html/resources/views/frontend/folder/folder_single.blade.php ENDPATH**/ ?>