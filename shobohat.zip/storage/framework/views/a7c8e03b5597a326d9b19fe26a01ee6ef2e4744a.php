
<?php $__env->startSection('backend-head'); ?>
    <link href="https://fonts.googleapis.com/css?family=Montserrat:300,400,500,600" rel="stylesheet">
    <!-- BEGIN: Vendor CSS-->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('backend')); ?>/app-assets/vendors/css/vendors-rtl.min.css">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('backend')); ?>/app-assets/vendors/css/forms/select/select2.min.css">
    <!-- END: Vendor CSS-->
    <!-- BEGIN: Theme CSS-->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('backend')); ?>/app-assets/css-rtl/bootstrap.css">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('backend')); ?>/app-assets/css-rtl/bootstrap-extended.css">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('backend')); ?>/app-assets/css-rtl/colors.css">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('backend')); ?>/app-assets/css-rtl/components.css">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('backend')); ?>/app-assets/css-rtl/themes/dark-layout.css">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('backend')); ?>/app-assets/css-rtl/themes/semi-dark-layout.css">

    <!-- BEGIN: Page CSS-->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('backend')); ?>/app-assets/css-rtl/core/menu/menu-types/vertical-menu.css">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('backend')); ?>/app-assets/css-rtl/core/colors/palette-gradient.css">
    <!-- END: Page CSS-->
    <!-- BEGIN: Custom CSS-->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('backend')); ?>/app-assets/css-rtl/custom-rtl.css">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('backend')); ?>/assets/css/style-rtl.css">
    <style>
        .note-btn-group i{
            color: white;
        }
    </style>
    <!-- END: Custom CSS-->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('backend-main'); ?>
    <section class="tooltip-validations" id="tooltip-validation">
        <div class="row">
            <div class="col-12">
                <?php echo $__env->make('common.done', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
            <div class="col-12">
                <div class="card">
                    <div class="card-header">
                        <h4 class="card-title">ارسال رسالة جديدة الى المتابعين</h4>
                    </div>
                    <div class="card-content">
                        <div class="card-body">
                            <form action="<?php echo e(route('emailForm')); ?>" method="post">
                                <?php echo e(csrf_field()); ?>

                                <?php echo $__env->make('common.errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                <div class="form-group">
                                    <div class="row">
                                        <div class="col-md-2">
                                            <label for="title">عنوان الرسالة</label>
                                        </div>
                                        <div class="col-md-10">
                                            <input type="text" id="title" name="title" class="form-control" value="<?php echo e(old('title')); ?>" placeholder="عنوان الرسالة">
                                        </div>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <div class="row">
                                        <div class="col-md-2">
                                            <label for="msg">محتوى الرسالة</label>
                                        </div>
                                        <div class="col-md-10">
                                            <textarea name="msg" id="msg" class="form-control" rows="10" placeholder="محتوى الرسالة "><?php echo e(old('msg')); ?></textarea>
                                        </div>
                                    </div>
                                </div>
                                <hr>
                                <div class="clearfix"></div>
                                <div class="form-group">
                                    <div class="row">
                                        <div class="col-md-2"></div>
                                        <div class="col-md-2">
                                            <button type="submit" class="btn btn-success form-control">ارسال</button>
                                        </div>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('backend-footer'); ?>
    <!-- BEGIN: Vendor JS-->
    <script src="<?php echo e(asset('backend')); ?>/app-assets/vendors/js/vendors.min.js"></script>
    <!-- BEGIN Vendor JS-->
    <!-- BEGIN: Page Vendor JS-->
    <script src="<?php echo e(asset('backend')); ?>/app-assets/vendors/js/forms/select/select2.full.min.js"></script>
    <!-- END: Page Vendor JS-->
    <!-- BEGIN: Theme JS-->
    <script src="<?php echo e(asset('backend')); ?>/app-assets/js/core/app-menu.js"></script>
    <script src="<?php echo e(asset('backend')); ?>/app-assets/js/core/app.js"></script>
    <script src="<?php echo e(asset('backend')); ?>/app-assets/js/scripts/components.js"></script>
    <!-- END: Theme JS-->
    <!-- BEGIN: Page JS-->
    <script src="<?php echo e(asset('backend')); ?>/app-assets/js/scripts/forms/form-tooltip-valid.js"></script>
    <script src="<?php echo e(asset('backend')); ?>/app-assets/js/scripts/forms/select/form-select2.js"></script>
    <!-- END: Page JS-->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/nej76515k7il/public_html/resources/views/backend/subscribers/email.blade.php ENDPATH**/ ?>