<div id="comments" class="tabcontent">
    <div class="tabs">
        <div class="container">
            <div class="title">
                <h4 class="sectiontitle mb-5">
                    تعليقاتي
                </h4>
            </div>
            <div class="alltabs">
                <div class="content">
                    <div class="tab-content">
                        <div class=" tab-pane active">
                            <div class="row quesdetails">
                                <div class="col-md-2"> رقم السؤال</div>
                                <div class="col-md-5">موضوع السؤال</div>
                                <div class="col-md-3 text-center">تاريخ التعليق</div>
                                <div class="col-md-2">حذف</div>
                            </div>
                            <?php if(count($comments) > 0): ?>
                            <table class="table example table-borderless" style="width:100%">
                                <thead style="display:none;">
                                <tr>
                                    <th hidden></th>
                                    <th></th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td hidden></td>
                                        <td>
                                            <div class="allques">
                                                <div class="row quesdetailsans">
                                                    <div class="col-md-2 d-center pigmartop"><?php echo e($comment->question->id); ?></div>
                                                    <div class="col-md-5 d-center pigmartop"><?php echo e($comment->question->mini_question); ?></div>
                                                    <div class="col-md-3 text-center d-center pigmartop"> <i class="fas fa-calendar-alt"></i>
                                                        <?php echo e(Carbon\Carbon::parse($comment->created_at)->format('d-m-Y')); ?>

                                                    </div>
                                                    <div class="col-md-2 text-center d-center pigmartop"><h4 class="m-0"><span class="badge"></span></h4>
                                                    </div>
                                                </div>
                                                <div class="row quesmoredetails">
                                                    <div class="col-md-2"></div>
                                                    <div class="col-md-8  questext d-center pigmartop">التعليق : <?php echo e($comment->comment); ?></div>
                                                    <div class="col-md-2  text-center trash">
                                                        <a title="" onclick="return false;" object_id="<?php echo e($comment->id); ?>"
                                                           delete_url="/delete/comment/" class="edit-btn-table remove-alert" href="#">
                                                            <i class="fas fa-trash-alt"></i>
                                                        </a>
                                                    </div>
                                                </div>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                            <?php else: ?>
                                <br>
                                <div class="alert alert-warning">
                                    <h3>
                                        لم تقم بإضافة تعليق بعد ....
                                    </h3>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div><?php /**PATH H:\laravel blogs\shobohat\resources\views/frontend/profile/content_sections/comments.blade.php ENDPATH**/ ?>