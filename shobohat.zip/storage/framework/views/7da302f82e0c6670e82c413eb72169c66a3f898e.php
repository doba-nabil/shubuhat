<?php $__env->startSection('pageTitle', $book->title); ?>
<?php $__env->startSection('frontend-main'); ?>
    <div class="total-artical">
        <div class="sobts">
            <div class="shobohat mb-5">
                <div class="container">
                    <div class="allshobohat">
                        <div class="title">
                            <h4 class="titleshop mt-5 mb-5">
                               <?php echo e($book->title); ?>

                            </h4>
                        </div>
                        <div class="download-share d-colm">
                            <div class="row download-sharebox">
                                <div class="col-md-2 numbs minimartop">
                                    <i class="fas fa-stream"></i>
                                    <?php echo e($book->id); ?>

                                </div>
                                <div class="vl"></div>
                                <div class="col-md-3 time-date minimartop">
                                    تاريخ النشر :
                                    <?php echo e(Carbon\Carbon::parse($book->created_at)->format('d-m-Y')); ?>

                                </div>
                                <div class="vl"></div>
                                <div class="col-md-6 views d-colm minimartop">
                                    المشاهدات :
                                    <?php echo e($book->views); ?>

                                    <div class="icondownlod minimartop">
                                        <a style="cursor: pointer" type="button" data-toggle="modal" data-target="#share">
                                            <i class="fas fa-share-alt"></i>
                                        </a>
                                        <a href="<?php echo e(asset('pictures/books/' . $book->file->file)); ?>" download=""><i class="fas fa-download"></i></a>
                                    </div>
                                </div>
                            </div>
                            <div class="textans textansmine">
                                <div class="row">
                                    <div class="col-md-2">
                                        <?php if(isset($book->mainImage->image)): ?>
                                            <img style="width: 100%" src="<?php echo e(asset('pictures/media/' . $book->mainImage->image)); ?>">
                                        <?php else: ?>
                                            <img style="width: 100%" src="<?php echo e(asset('frontend/img/empty.png')); ?>" alt=""/>
                                        <?php endif; ?>
                                    </div>
                                    <div class="col-md-10">
                                        <h4>نبذة عن الكتاب</h4>
                                        <p>
                                            <?php echo e($book->body); ?>

                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- share modale -->
    <div class="modal fade" id="share" tabindex="-1" role="dialog" aria-labelledby="share_title" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title text-primary" id="share_title">مشاركة الشبهة</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <?php $actual_link = "http://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]"; ?>
                    <ul>
                        <li title="مشاركة على فيس بوك">
                            <a href="https://www.facebook.com/sharer/sharer.php?u=<?= $actual_link; ?>" target="_blank">
                                <img src="<?php echo e(asset('frontend/img/facebook.png')); ?>">
                            </a>
                        </li>
                        <li title="مشاركة على تويتر">
                            <a href="http://twitter.com/home?status=<?php echo e($book->title); ?>+<?= $actual_link; ?>" target="_blank">
                                <img src="<?php echo e(asset('frontend/img/twitter.png')); ?>">
                            </a>
                        </li>
                        <li title="مشاركة على الواتس اب">
                            <a href="https://api.whatsapp.com://send?text=<?= $actual_link; ?>" target="_blank" title="Share on whatsapp">
                                <img src="<?php echo e(asset('frontend/img/whatsapp.png')); ?>">
                            </a>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/nej76515k7il/public_html/resources/views/frontend/book/book_single.blade.php ENDPATH**/ ?>