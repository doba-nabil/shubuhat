
<?php $__env->startSection('backend-head'); ?>
    <link href="https://fonts.googleapis.com/css?family=Montserrat:300,400,500,600" rel="stylesheet">
    <!-- BEGIN: Vendor CSS-->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('backend')); ?>/app-assets/vendors/css/vendors-rtl.min.css">
    <link rel="stylesheet" type="text/css"
          href="<?php echo e(asset('backend')); ?>/app-assets/vendors/css/file-uploaders/dropzone.min.css">
    <link rel="stylesheet" type="text/css"
          href="<?php echo e(asset('backend')); ?>/app-assets/vendors/css/tables/datatable/datatables.min.css">
    <link rel="stylesheet" type="text/css"
          href="<?php echo e(asset('backend')); ?>/app-assets/vendors/css/tables/datatable/extensions/dataTables.checkboxes.css">
    <!-- END: Vendor CSS-->
    <link href="<?php echo e(asset('backend')); ?>/summernote.min.css" rel="stylesheet">
    <!-- BEGIN: Theme CSS-->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('backend')); ?>/app-assets/css-rtl/bootstrap.css">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('backend')); ?>/app-assets/css-rtl/bootstrap-extended.css">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('backend')); ?>/app-assets/css-rtl/colors.css">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('backend')); ?>/app-assets/css-rtl/components.css">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('backend')); ?>/app-assets/css-rtl/themes/dark-layout.css">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('backend')); ?>/app-assets/css-rtl/themes/semi-dark-layout.css">
    <!-- BEGIN: Page CSS-->
    <link rel="stylesheet" type="text/css"
          href="<?php echo e(asset('backend')); ?>/app-assets/css-rtl/core/menu/menu-types/vertical-menu.css">
    <link rel="stylesheet" type="text/css"
          href="<?php echo e(asset('backend')); ?>/app-assets/css-rtl/core/colors/palette-gradient.css">
    <link rel="stylesheet" type="text/css"
          href="<?php echo e(asset('backend')); ?>/app-assets/css-rtl/plugins/file-uploaders/dropzone.css">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('backend')); ?>/app-assets/css-rtl/pages/data-list-view.css">
    <!-- END: Page CSS-->
    <!-- BEGIN: Custom CSS-->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('backend')); ?>/app-assets/css-rtl/custom-rtl.css">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('backend')); ?>/assets/css/style-rtl.css">
    <!-- END: Custom CSS-->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('backend-main'); ?>
    <!-- BEGIN: Content-->
    <div class="content-body">
        
        <div class="modal fade" id="mini_question" tabindex="-1" role="dialog" aria-labelledby="mini_question_title" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLongTitle">تعديل اختصار السؤال</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                       <strong>السؤال : </strong>
                        <span><?php echo e($question->question); ?></span>
                        <hr>
                        <form method="post" action="<?php echo e(route('mini_question')); ?>">
                            <?php echo csrf_field(); ?>
                            <div class="form-row">
                                <input name="question_id" value="<?php echo e($question->id); ?>" hidden>
                                <div class="col-md-12 col-12 mb-3">
                                    <label for="mini_question">اختصار السؤال</label>
                                    <textarea rows="5" name="mini_question" class="form-control" placeholder="اختصار السؤال"
                                              required><?php echo e($question->mini_question ?? ''); ?></textarea>
                                    <?php $__errorArgs = ['mini_question'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" data-dismiss="modal">اغلاق</button>
                                <button type="submit" class="btn btn-primary">حفظ</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        
        
        <div class="modal fade" id="mini_answer" tabindex="-1" role="dialog" aria-labelledby="mini_answer_title" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLongTitle"> اجابة السؤال بشكل مختصر والمصادر</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                       <strong>السؤال : </strong>
                        <span><?php echo e($question->question); ?></span>
                        <hr>
                        <form method="post" action="<?php echo e(route('mini_answer')); ?>"  enctype="multipart/form-data" >
                            <?php echo csrf_field(); ?>
                            <div class="form-row">
                                <input name="question_id" value="<?php echo e($question->id); ?>" hidden>
                                <div class="col-md-12 col-12 mb-3">
                                    <label for="mini_question">الاجابة بإختصار ( اختياري )</label>
                                    <textarea rows="5" name="mini_answer" class="form-control" placeholder="الاجابة بشكل مختصر"><?php echo e($question->mini_answer ?? ''); ?></textarea>
                                    <?php $__errorArgs = ['mini_answer'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="col-md-12 col-12 mb-3">
                                    <label for="sources">المصادر</label>
                                    <textarea rows="5" name="sources" class="form-control summernote" placeholder="المصادر"
                                              ><?php echo e($question->sources ?? ''); ?></textarea>
                                    <?php $__errorArgs = ['sources'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <hr>
                                <div class="col-md-12 col-12 mb-3">
                                    <input <?php if($question->kind == 0): ?> checked <?php endif; ?> type="radio" id="linkRadio" name="kind" value="0">
                                    <label for="linkRadio">رابط</label><br>
                                    <input <?php if($question->kind == 1): ?> checked <?php endif; ?> type="radio" id="fileRadio" name="kind" value="1">
                                    <label for="fileRadio">ملف</label><br>
                                    <?php $__errorArgs = ['kind'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="col-md-12 col-12 mb-3 link">
                                    <label for="link">الرابط</label>
                                    <input type="text" name="link" class="form-control" id="link" placeholder="رابط اليوتيوب" value="<?php echo e($question->file->link ?? ''); ?>">
                                    <div class="col-md-12 text-center">
                                        <?php if(isset($question->file->link)): ?>
                                            <?php
                                            $string     =  $question->file->link ;
                                            $search     = '/youtube\.com\/watch\?v=([a-zA-Z0-9]+)/smi';
                                            $replace    = "youtube.com/embed/$1";
                                            $url = preg_replace($search,$replace,$string);
                                            ?>
                                            <iframe width="420" height="315" src='<?php echo e($url); ?>?modestbranding=1' allowfullscreen>
                                            </iframe>
                                        <?php endif; ?>
                                    </div>
                                    <?php $__errorArgs = ['link'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="col-md-12 col-12 mb-3 file">
                                    <label for="link">الفيديو بصيغة ( 3gp , MP4 , flv )
                                        max 10 MB
                                    </label>
                                    <input type="file" name="file" class="form-control" id="file-input">
                                    <div class="col-md-12 text-center">
                                        <?php if(isset($question->file->file)): ?>
                                        <video id="old" width="300" height="300" controls>
                                                <source src="<?php echo e(asset('pictures/video/' . $question->file->file)); ?>">
                                        </video>
                                        <?php endif; ?>
                                        <video id="video" width="300" height="300" controls></video>
                                    </div>
                                    <?php $__errorArgs = ['file'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <hr>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" data-dismiss="modal">اغلاق</button>
                                <button type="submit" class="btn btn-primary">حفظ</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        
        
        <div class="modal fade" id="createmodal" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle"
             aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="createmodal"><?php echo e($question->mini_question ?? ''); ?></h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <form method="post" action="<?php echo e(route('answers.store')); ?>" id="myform">
                            <?php echo csrf_field(); ?>
                            <div class="form-row">
                                <input name="question_id" value="<?php echo e($question->id); ?>" hidden>
                                <div class="col-md-12 col-12 mb-3">
                                    <label for="title">العنصر</label>
                                    <input type="text" name="title" class="form-control" id="title" placeholder="العنصر"
                                           value="<?php echo e(old('title')); ?>" required>
                                    <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="col-md-12 col-12 mb-3">
                                    <label for="answer">نص الاجابة</label>
                                    <textarea rows="10" name="answer" class="form-control" placeholder="نص الاجابة"
                                              required><?php echo e(old('answer')); ?></textarea>
                                    <?php $__errorArgs = ['answer'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="col-sm-12 col-12 mb-3">
                                    <div class="text-bold-600 font-medium-2">
                                        الترتيب بالنسبة للعناصر
                                    </div>
                                    <div class="form-group">
                                        <div class="form-group">
                                            <input type="number" min="1" name="order" class="form-control" id="order" placeholder="ترتيب العناصر"
                                                   value="<?php echo e(old('order')); ?>" required>
                                            <?php $__errorArgs = ['order'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="text-danger"><?php echo e($message); ?></span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                    <?php $__errorArgs = ['order'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <hr>
                            <button style="width: 100%" class="btn btn-primary" type="submit">اضافة</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    
    <!-- Data list view starts -->
        <div class="col-12">
            <?php echo $__env->make('common.done', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php echo $__env->make('common.errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
        <div class="row">
            <div class="col-md-10 col-sm-12 col-xs-12">
                <section id="global-settings" class="card">
                    <div class="card-header">
                        <h4 class="card-title">
                            <span class="text-bold-700 border-bottom pb-1"> السؤال بإختصار :</span>
                            <?php if(!empty($question->mini_question)): ?>
                                <?php echo e($question->mini_question); ?>

                            <?php else: ?>
                                <span class="alert alert-warning">لم يتم اضافة اختصار بعد</span>
                            <?php endif; ?>
                            <button type="button" class="btn btn-primary px-1" data-toggle="modal" data-target="#mini_question">
                                <i class="fa fa-edit"></i>
                            </button>
                        </h4>
                    </div>
                    <div class="card-content">
                        <div class="card-body">
                            <div class="card-text">
                                <p>
                                    <span class="text-bold-700 pb-1">نص السؤال :</span>
                                    <?php echo e($question->question); ?>

                                </p>
                            </div>
                        </div>
                    </div>
                </section>
            </div>
            <div style="justify-content: space-between;display: flex;" class="col-md-2 col-sm-12 col-xs-12">
                <div style="width: 100%" class="card p-1 text-center">
                <span class="display-inline-block">
                    <i class="fa fa-list-ol" aria-hidden="true"></i>
                    رقم السؤال
                    <br>
                    <?php echo e($question->id); ?>

                </span>
                    <hr>
                    <span class="display-inline-block">
                    <i class="fa fa-eye" aria-hidden="true"></i>
                    عدد الزيارات
                        <br>
                        <?php echo e($question->views); ?>

                </span>
                </div>
            </div>
        </div>
        <section id="data-thumb-view" class="data-thumb-view-header">
            <div class="action-btns d-none">
                <div class="btn-dropdown mr-1 mb-1">
                    <div class="btn-group dropdown actions-dropodown">
                        <button type="button" class="btn btn-success px-1 py-1 dropdown-toggle waves-effect waves-light"
                                data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            خيارات
                        </button>
                        <div class="dropdown-menu dropdown-menu-right">
                            <a class="dropdown-item" type="button" data-toggle="modal" data-target="#createmodal">
                                <i class="fa fa-plus"></i>اضافة جديد
                            </a>
                            <a class="dropdown-item delete-all" onclick="return false;" delete_url="/delete_answers/">
                                حذف الكل</a>
                        </div>
                    </div>
                </div>
            </div>
            <!-- dataTable starts -->
            <div class="table-responsive">

                <table class="table data-thumb-view">
                    <thead>
                    <tr>
                        <th colspan="4">عناصر اجابة السؤال ( يتم اضافة عنصر في حالة عدم وجود عناصر متعددة )</th>
                    </tr>
                    <tr>
                        <th hidden></th>
                        <th>الترتيب</th>
                        <th>العنصر</th>
                        <th>تصفح</th>
                        <th>خيارات</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $question->answers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $answer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="modal fade" id="exampleModalCenter<?php echo e($answer->id); ?>" tabindex="-1"
                             role="dialog" aria-labelledby="exampleModalCenterTitle<?php echo e($answer->id); ?>"
                             aria-hidden="true">
                            <div class="modal-dialog modal-dialog-centered" role="document">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h5 class="modal-title"
                                            id="exampleModalLongTitle<?php echo e($answer->id); ?>"><?php echo e(substr( $answer->title, 0, 50 )); ?></h5>
                                        <button type="button" class="close" data-dismiss="modal"
                                                aria-label="Close">
                                            <span aria-hidden="true">&times;</span>
                                        </button>
                                    </div>
                                    <div class="modal-body">
                                        <form method="post"
                                              action="<?php echo e(route('answers.update' , $answer->id)); ?>"
                                              id="myform">
                                            <?php echo csrf_field(); ?>
                                            <?php echo e(method_field('PATCH')); ?>

                                            <div class="form-row">
                                                <input name="question_id" value="<?php echo e($question->id); ?>"
                                                       hidden>
                                                <div class="col-md-12 col-12 mb-3">
                                                    <label for="title<?php echo e($answer->id); ?>">العنصر</label>
                                                    <input type="text" name="title" class="form-control"
                                                           id="title<?php echo e($answer->id); ?>" placeholder="العنصر"
                                                           value="<?php echo e($answer->title); ?>" required>
                                                    <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <span class="text-danger"><?php echo e($message); ?></span>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </div>
                                                <div class="col-md-12 col-12 mb-3">
                                                    <label for="answer<?php echo e($answer->id); ?>">نص الاجابة</label>
                                                    <textarea rows="10" name="answer"
                                                              id="answer<?php echo e($answer->id); ?>"
                                                              class="form-control"
                                                              placeholder="نص الاجابة"
                                                              required><?php echo e($answer->answer); ?></textarea>
                                                    <?php $__errorArgs = ['answer'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <span class="text-danger"><?php echo e($message); ?></span>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </div>
                                                <div class="col-sm-12 col-12 mb-3">
                                                    <div class="text-bold-600 font-medium-2">
                                                        الترتيب بالنسبة للعناصر
                                                    </div>
                                                    <div class="form-group">
                                                        <div class="form-group">
                                                            <input type="number" min="1" name="order" class="form-control" id="order" placeholder="ترتيب العناصر"
                                                                   value="<?php echo e($answer->order); ?>" required>
                                                            <?php $__errorArgs = ['order'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                            <span class="text-danger"><?php echo e($message); ?></span>
                                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                        </div>
                                                    </div>
                                                    <?php $__errorArgs = ['order'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <span class="text-danger"><?php echo e($message); ?></span>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </div>
                                            </div>
                                            <hr>
                                            <button style="width: 100%" class="btn btn-primary" type="submit">حفظ</button>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <tr class="delete-all-cats">
                            <td hidden></td>
                            <td>
                                <?php echo e($answer->order); ?>

                            </td>
                            <td class="product-name"><?php echo e(substr( $answer->title, 0, 50 )); ?></td>
                            <td class="product-name">
                                <a class="edit-btn-table" href="<?php echo e(route('answers.show' , $answer->id)); ?>">
                                    <i class="fa fa-eye fa-2x"></i></a>
                            </td>
                            <td class="product-action">
                                <a type="button" data-toggle="modal"
                                   data-target="#exampleModalCenter<?php echo e($answer->id); ?>">
                                    <i class="feather icon-edit"></i>
                                </a>
                                <a title="" onclick="return false;" object_id="<?php echo e($answer->id); ?>"
                                   delete_url="/answers/" class="edit-btn-table remove-alert" href="#">
                                    <i class="feather icon-trash"></i></a>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
            <!-- dataTable ends -->
        </section>
        <!-- Data list view end -->
        <section id="global-settings" class="card mt-2">
            <div style="justify-content: space-between;display: flex;" class="card-header">
                <h4 class="card-title">
                    <span class="text-bold-700 border-bottom pb-1"> اختصار الاجابة والمصادر :</span>
                </h4>
                <button type="button" class="btn btn-primary px-1" data-toggle="modal" data-target="#mini_answer">
                    <i class="fa fa-edit"></i>
                </button>
            </div>
            <div class="card-content">
                <div class="card-body">
                    <div class="card-text">
                        <strong>الاجابة</strong>
                        <p class="mt-2">
                            <?php if(!empty($question->mini_answer)): ?>
                                <?php echo e($question->mini_answer); ?>

                            <?php else: ?>
                                <span class="alert alert-warning">لم يتم اضافة اختصار للاجابة بعد</span>
                            <?php endif; ?>
                        </p>
                        <hr>
                        <strong>المصادر</strong>
                        <p class="mt-2">
                            <?php if(!empty($question->sources)): ?>
                                <?php echo htmlspecialchars_decode($question->sources) ?>
                            <?php else: ?>
                                <span class="alert alert-warning">لم يتم اضافة مصادر للاجابة بعد</span>
                            <?php endif; ?>
                        </p>
                        <hr>
                        <strong>الفيديو</strong>
                        <p class="mt-2">
                        <?php if(!empty($question->file->file) || isset($question->file->link)): ?>
                            <div class="col-md-12 col-12 mb-3 link">
                                <label for="link">الرابط</label>
                                <div class="col-md-12 text-center">
                                    <?php if(isset($question->file->link)): ?>
                                        <?php
                                        $string     =  $question->file->link ;
                                        $search     = '/youtube\.com\/watch\?v=([a-zA-Z0-9]+)/smi';
                                        $replace    = "youtube.com/embed/$1";
                                        $url = preg_replace($search,$replace,$string);
                                        ?>
                                        <iframe width="420" height="315" src='<?php echo e($url); ?>?modestbranding=1' allowfullscreen>
                                        </iframe>
                                    <?php endif; ?>
                                </div>
                               <a style="width:100%" href="<?php echo e(route('delete_video' , $question->file->id)); ?>" class="btn btn-danger">حذف الفيديو</a>
                            </div>
                            <div class="col-md-12 col-12 mb-3 file">
                                <label for="link">الفيديو بصيغة ( 3gp , MP4 , flv )
                                    max 10 MB
                                </label>
                                <div class="col-md-12 text-center">
                                    <?php if(isset($question->file->file)): ?>
                                        <video id="old" width="300" height="300" controls>
                                            <source src="<?php echo e(asset('pictures/video/' . $question->file->file)); ?>">
                                        </video>
                                    <?php endif; ?>
                                    <video id="video" width="300" height="300" controls></video>
                                   <a style="width:100%" href="<?php echo e(route('delete_video' , $question->file->id)); ?>" class="btn btn-danger">حذف الفيديو</a>
                                </div>
                            </div>
                        <?php else: ?>
                            <span class="alert alert-warning">لم يتم اضافة فيديو</span>
                            <?php endif; ?>
                            </p>
                    </div>
                </div>
            </div>
        </section>
    </div>
    <!-- END: Content-->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('backend-footer'); ?>
    <!-- BEGIN: Vendor JS-->
    <script src="<?php echo e(asset('backend')); ?>/app-assets/vendors/js/vendors.min.js"></script>
    <!-- BEGIN Vendor JS-->
    <!-- BEGIN: Page Vendor JS-->
    <script src="<?php echo e(asset('backend')); ?>/app-assets/vendors/js/extensions/dropzone.min.js"></script>
    <script src="<?php echo e(asset('backend')); ?>/app-assets/vendors/js/tables/datatable/datatables.min.js"></script>
    <script src="<?php echo e(asset('backend')); ?>/app-assets/vendors/js/tables/datatable/datatables.buttons.min.js"></script>
    <script src="<?php echo e(asset('backend')); ?>/app-assets/vendors/js/tables/datatable/datatables.bootstrap4.min.js"></script>
    <script src="<?php echo e(asset('backend')); ?>/app-assets/vendors/js/tables/datatable/buttons.bootstrap.min.js"></script>
    <script src="<?php echo e(asset('backend')); ?>/app-assets/vendors/js/tables/datatable/dataTables.select.min.js"></script>
    <script src="<?php echo e(asset('backend')); ?>/app-assets/vendors/js/tables/datatable/datatables.checkboxes.min.js"></script>
    <!-- END: Page Vendor JS-->
    <!-- BEGIN: Theme JS-->
    <script src="<?php echo e(asset('backend')); ?>/app-assets/js/core/app-menu.js"></script>
    <script src="<?php echo e(asset('backend')); ?>/app-assets/js/core/app.js"></script>
    <script src="<?php echo e(asset('backend')); ?>/app-assets/js/scripts/components.js"></script>
    <script src="<?php echo e(asset('backend')); ?>/custom-sweetalert.js"></script>
    <!-- END: Theme JS-->
    <script src="<?php echo e(asset('backend')); ?>/summernote.min.js"></script>
    <script src="https://cdn.jsdelivr.net/jquery.validation/1.16.0/jquery.validate.min.js"></script>
    <script src="https://cdn.jsdelivr.net/jquery.validation/1.16.0/additional-methods.min.js"></script>
    <script>
        $(document).ready(function() {
            $('.summernote').summernote({
                tabsize: 2,
                height: 100,
                toolbar: [
                    ['insert', ['link']],
                ],
            });
        });
        $(document).ready(function () {
            $("#myform").validate({
                rules: {
                    title: {
                        required: true,
                        minlength: 3,
                        maxlength: 500,
                    },
                    answer: {
                        required: true,
                    },
                },
                messages: {
                    title: {
                        required: 'هذا الحقل مطلوب',
                        minlength: 'هذا الحقل مطلوب اقل من المسموح',
                    },
                    answer: {
                        required: 'هذا الحقل مطلوب',
                    },
                }
            });
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH H:\laravel blogs\shobohat\resources\views/backend/questions/moderator_answer.blade.php ENDPATH**/ ?>