<div class="tophead">
    <div class="container">
        <div class="row">
            <div class="col-md-4">
                <div class="socialhead d-center">
                    <?php if(!empty($option->facebook)): ?>
                        <a href="<?php echo e($option->facebook); ?>"><i class="fab fa-facebook-f"></i></a>
                    <?php endif; ?>
                    <?php if(!empty($option->twitter)): ?>
                        <a href="<?php echo e($option->twitter); ?>"><i class="fab fa-twitter"></i></a>
                    <?php endif; ?>
                    <?php if(!empty($option->youtube)): ?>
                        <a href="<?php echo e($option->youtube); ?>"><i class="fab fa-youtube"></i></a>
                    <?php endif; ?>
                    <?php if(!empty($option->insta)): ?>
                        <a href="<?php echo e($option->insta); ?>"><i class="fab fa-instagram"></i></a>
                    <?php endif; ?>
                </div>
            </div>
            <div class="col-md-4 minimartop">
                <div class="datehead text-center d-flex align-items-center justify-content-center ">
                    <p>
                        <?php echo e($date); ?>

                    </p>
                </div>
            </div>
            <?php if(auth()->guard()->check()): ?>
                <div class="col-md-4 d-center minimartop">
                    <div class="accounthead d-center">
                        <div class="dropdown ">
                            <button class="dropbtn ">
                                <?php echo e(Auth::user()->name); ?>

                                <i class="fas fa-user-circle"></i>
                            </button>
                            <div class="dropdown-content">
                                <a href="<?php echo e(route('profile')); ?>">
                                    <i class="fas fa-user"></i>
                                    بياناتى الشخصية
                                </a>
                                <a title="تسجيل الخروج" href="<?php echo e(route('logout')); ?>"
                                   onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
                                    <i class="fas fa-sign-out-alt"></i>
                                    تسجيل الخروج
                                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST"
                                          style="display: none;">
                                        <?php echo e(csrf_field()); ?>

                                    </form>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            <?php else: ?>
                <div class="col-md-4 d-center minimartop">
                    <div class="accounthead d-center">
                        <div class="dropdown">
                            <button class="dropbtn w-100 h-100">
                                تسجيل الدخول <i class="fas fa-user-circle"></i>
                            </button>
                            <div class="dropdown-content">
                                <a>
                                    <i class="fas fa-user"></i>
                                    <!-- Button trigger modal -->
                                    <button type="button" class="btn" data-toggle="modal"
                                            data-target="#exampleModalCenter1">
                                        تسجيل الدخول
                                    </button>
                                </a>
                                <a>
                                    <i class="fas fa-question"></i>
                                    <button type="button" class="btn" data-toggle="modal"
                                            data-target="#exampleModalCenter2">
                                        انشاء حساب
                                    </button>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- Modal register-->
                <div class="modal fade" id="exampleModalCenter1" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
                    <div class="modal-dialog modal-dialog-centered" role="document">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="exampleModalLongTitle">تسجيل الدخول</h5>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                            <div class="modal-body">
                                <div class="loginform">
                                    <div class="top">
                                        <div class="textfo">
                                            <h3>أهلاً بعودتك</h3>
                                            <p>قم بتسجيل الدخول لموقع شبهات</p>
                                        </div>
                                        <img src="<?php echo e(asset('frontend')); ?>/img/Image 10.png" alt="banner">
                                    </div>
                                    <div class="logformsty">
                                        <img src="<?php echo e(asset('frontend')); ?>/img/222.png" alt="logo">
                                        <form method="POST" action="<?php echo e(route('login')); ?>" class="login_form">
                                            <?php echo csrf_field(); ?>
                                            <div class="form-group">
                                                <label for="email">البريد الإلكترونى</label>
                                                <input type="email" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                       name="email" value="<?php echo e(old('email')); ?>" required autocomplete="email"
                                                       placeholder="Admin@engaz.com">
                                                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <span class="invalid-feedback" role="alert">
                                                        <strong><?php echo e($message); ?></strong>
                                                    </span>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                            <div class="form-group">
                                                <label for="pass">كلمة المرور </label>
                                                <input type="password" class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                       name="password" required autocomplete="current-password">
                                                <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <span class="invalid-feedback" role="alert">
                                                        <strong><?php echo e($message); ?></strong>
                                                    </span>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                            <div class="form-group row">
                                                <div class="col-sm-10">
                                                    <div class="form-check">
                                                        <input class="form-check-input" type="checkbox" name="remember" id="remember" <?php echo e(old('remember') ? 'checked' : ''); ?>>
                                                        <label class="form-check-label" for="gridCheck">
                                                            تذكرنى
                                                        </label>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="form-group row">
                                                <div class="col-md-12">
                                                    <button type="submit" class="btn loginfornsty">تسجيل الدخول</button>
                                                </div>
                                            </div>
                                        </form>
                                        
                                        
                                            
                                            
                                        

                                    </div>
                                </div>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" data-dismiss="modal">اغلاق</button>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- Modal -->
                <!-- Modal login-->
                <div class="modal fade" id="exampleModalCenter2" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
                    <div class="modal-dialog modal-dialog-centered" role="document">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="exampleModalLongTitle">تسجيل جديد </h5>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                            <div class="modal-body">
                                <div class="loginform">
                                    <div class="top">
                                        <div class="textfo">
                                            <p>قم بانشاء حساب لموقع شبهات</p>
                                        </div>
                                        <img src="<?php echo e(asset('frontend')); ?>/img/Image 10.png" alt="banner">
                                    </div>
                                    <div class="logformsty">
                                        <img src="<?php echo e(asset('frontend')); ?>/img/222.png" alt="logo">
                                        <form method="POST" action="<?php echo e(route('register')); ?>" class="register_form">
                                            <?php echo csrf_field(); ?>
                                            <div class="form-group">
                                                <label for="name">اسم المستخدم</label>
                                                <input id="name" type="text" class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="name" value="<?php echo e(old('name')); ?>" required >
                                                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="invalid-feedback" role="alert">
                                                    <strong><?php echo e($message); ?></strong>
                                                </span>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                            <div class="form-group">
                                                <label for="email2">البريد الإلكترونى</label>
                                                <input id="email2" type="email" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="email" value="<?php echo e(old('email')); ?>" required autocomplete="email">
                                                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="invalid-feedback" role="alert">
                                                    <strong><?php echo e($message); ?></strong>
                                                </span>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                            <div class="form-group">
                                                <label for="password2">كلمة المرور </label>
                                                <input id="password2" type="password" class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="password" required autocomplete="new-password">

                                                <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                            <div class="form-group">
                                                <label for="password-confirm">اعادة كلمة المرور</label>
                                                <input id="password-confirm" type="password" class="form-control" name="password_confirmation" required autocomplete="new-password">
                                            </div>
                                            <div class="form-group row">
                                                <div class="col-sm-10">
                                                    <div class="form-check">
                                                        <input class="form-check-input" type="checkbox" id="gridCheck1">
                                                        <label class="form-check-label" for="gridCheck1">
                                                            تذكرنى
                                                        </label>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="form-group row">
                                                <div class="col-md-12">
                                                    <button type="submit" class="btn loginfornsty">تسجيل الدخول</button>
                                                </div>
                                            </div>
                                        </form>
                                        
                                        
                                            
                                            
                                        
                                    </div>
                                </div>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" data-dismiss="modal">اغلاق</button>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- Modal -->
            <?php endif; ?>
        </div>
    </div>
</div>
<!-- end top head  -->
<div id="fady"></div>
<!-- navbar  -->
<div id="navbar" class="mainnavbar">
    <div class="container container1">
        <nav class="navbar navbar-expand-lg navbar-light bg-light">
            <a class="navbar-brand" href="/">
                <img src="<?php echo e(asset('frontend')); ?>/img/لوجو الشبهات.png" alt="logo">
            </a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavDropdown"
                    aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNavDropdown">
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <a class="nav-link hvr-underline-from-center" href="/">
                            <i class="fas fa-home"></i>
                            الرئيسية
                        </a>
                    </li>
                    <li class="nav-item dropdown">
                        <a class="nav-link hvr-underline-from-center" href="#" id="navbarDropdown" role="button"
                           data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            <i class="fas fa-list"></i>
                            التصنيفات
                            <i class="fas fa-angle-down"></i>
                        </a>
                        <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <a class="dropdown-item" href="<?php echo e(route('category.show' , $category->slug)); ?>"><?php echo e($category->title); ?></a>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <a class="dropdown-item" href="<?php echo e(route('category.index')); ?>">جميع التصنيفات ....</a>
                        </div>
                    </li>
                    <li class="nav-item">
                        <i class="fas fa-place-of-worship"></i>
                        <a class="nav-link hvr-underline-from-center" href="<?php echo e(route('question.index')); ?>">الشبهات</a>
                    </li>
                    <li class="nav-item dropdown">
                        <a class="nav-link hvr-underline-from-center" href="#" id="navbarDropdown" role="button"
                           data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            <i class="fas fa-images"></i>
                            مكتبة الوسائط
                            <i class="fas fa-angle-down"></i>
                        </a>
                        <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                            <a class="dropdown-item" href="<?php echo e(route('video.index')); ?>"> فيديوهات</a>
                            <a class="dropdown-item" href="<?php echo e(route('audio.index')); ?>"> صوتيات</a>
                            <a class="dropdown-item" href="<?php echo e(route('book.index')); ?>"> كتب</a>
                            <a class="dropdown-item" href="<?php echo e(route('article.index')); ?>"> مقالات</a>
                        </div>
                    </li>
                    <li class="nav-item">
                        <i class="far fa-copy"></i>
                        <a class="nav-link hvr-underline-from-center" href="<?php echo e(route('folder.index')); ?>">ملفات متنوعة</a>
                    </li>
                    <li class="nav-item">
                        <i class="fas fa-question-circle"></i>
                        <a class="nav-link hvr-underline-from-center" href="<?php echo e(url('page/about-us')); ?>">من نحن</a>
                    </li>
                    <li class="nav-item">
                        <?php if(auth()->guard()->check()): ?>
                        <a class="nav-link hvr-underline-from-center" href="<?php echo e(route('profile')); ?>">
                            <i class="fas fa-question-circle"></i>
                            أرسل سؤال</a>
                        <?php else: ?>
                            <a style="cursor: pointer" class="nav-link hvr-underline-from-center" data-toggle="modal"
                               data-target="#exampleModalCenter1">
                                <i class="fas fa-question-circle"></i>
                                أرسل سؤال</a>
                        <?php endif; ?>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link hvr-underline-from-center" href="<?php echo e(route('contact_page')); ?>">
                            <i class="fas fa-phone-alt"></i>
                            إتصل بنا</a>
                    </li>
                </ul>
            </div>
        </nav>
    </div>
</div>
<!-- end navbar  -->
<!-- messages -->
<div class="messages">
    <?php echo $__env->make('common.done_frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('common.errors_frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>
<!-- end messages  -->

<?php /**PATH /home/nej76515k7il/public_html/resources/views/frontend/layout/header.blade.php ENDPATH**/ ?>