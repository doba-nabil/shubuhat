<?php if(count($data) > 0): ?>
    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $folder): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="item col-xs-4 col-lg-4">
    <a href="<?php echo e(route('folder.show' , $folder->slug)); ?>">
        <div class="thumbnail card">
            <div class="img-event">
                <?php if(isset( $folder->mainImage->image)): ?>
                    <img class="group image  list-group-image img-fluid" src="<?php echo e(asset('pictures/folders/' . $folder->mainImage->image)); ?>" alt="<?php echo e($folder->title); ?>">
                <?php else: ?>
                    <img class="group image  list-group-image img-fluid" src="<?php echo e(asset('frontend/img/empty.png')); ?>" alt="" />
                <?php endif; ?>
            </div>
            <div class="caption card-body">
                <h4 class="group group1 card-title inner list-group-item-heading list-group-item-heading2">
                    <?php echo e($folder->title); ?></h4>
                <p class="group group2 inner list-group-item-text list-group-item2">
                    <?php echo e($folder->body); ?>

                </p>
            </div>
        </div>
    </a>
</div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <div class="col-md-12 text-center mt-5">
        <div style="display: inline-block">
            <?php echo $data->links(); ?>

        </div>
    </div>
<?php else: ?>
    <div class="col-md-12">
        <br>
        <div class="alert alert-warning text-center">
            <h3>
                لا يوجد ملفات متنوعة....
            </h3>
        </div>
    </div>
<?php endif; ?>

<?php /**PATH /home/nej76515k7il/public_html/resources/views/frontend/folder/pagination_data.blade.php ENDPATH**/ ?>