<?php $__env->startSection('frontend-head'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('pageTitle', 'الملف الشخصي'); ?>
<?php $__env->startSection('frontend-main'); ?>
    <div class="clearfix"></div>
    <!-- maintab -->
    <div class="maintab my-5">
        <div class="container condf">
            <div class="titlemaintab mb-5">
                <h4 class="titleabout">
                    الملف الشخصي
                </h4>
                <p class="cont">مرحباً بك <?php echo e($user->name); ?></p>
            </div>
            <div class="row mb-3">
                <div class="col-md-4">
                    <div class="mainacc d-flex align-items-center">
                        <i class="fas fa-user-circle"></i>
                        <p>حسابى</p>
                    </div>
                </div>
            </div>
            <div style="width: 100%;" class="row rowresp">
                <div class="col-md-4">
                    <?php echo $__env->make('frontend.profile.tabs', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
                <div class="main-tab-content col-md-8">
                   <?php echo $__env->make('frontend.profile.content_sections.edit_profile', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                   <?php echo $__env->make('frontend.profile.content_sections.comments', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                   <?php echo $__env->make('frontend.profile.content_sections.favourite', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                   <?php echo $__env->make('frontend.profile.content_sections.question', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                   <?php echo $__env->make('frontend.profile.content_sections.send_question', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
            </div>
        </div>
    </div>
    <!-- end maintab -->
    <div class="clearfix"></div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('frontend-footer'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH H:\laravel blogs\shobohat\resources\views/frontend/profile/profile.blade.php ENDPATH**/ ?>