<div id="Paris" class="tabcontent">
    <div class="tabs">
        <div class="container">
            <div class="title">
                <h4 class="sectiontitle mb-5">
                    أسئلتى
                </h4>
            </div>
            <div class="alltabs">
                <div class="content">
                    <!-- Nav pills -->
                    <ul class="nav nav-pills" role="tablist">
                        <li class="nav-item">
                            <a class="nav-link active" data-toggle="pill" href="#ask">
                                أسئلة قيد الإجابة حالياً</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" data-toggle="pill" href="#answer">
                                أسئلة تم الإجابة عليها</a>
                        </li>
                    </ul>
                    <!-- Tab panes -->
                    <div class="tab-content">
                        <div id="ask" class=" tab-pane active">
                            <div class="row quesdetails">
                                <div class="col-md-2">رقم</div>
                                <div class="col-md-5">موضوع السؤال</div>
                                <div class="col-md-3 text-center">تاريخ السؤال</div>
                                <div class="col-md-2">حذف</div>
                            </div>
                            <?php if(count($not_answered_questions) > 0): ?>
                            <table class="table example table-borderless" style="width:100%">
                                <thead style="display:none;">
                                <tr>
                                    <th hidden></th>
                                    <th></th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php $__currentLoopData = $not_answered_questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td hidden></td>
                                        <td>
                                            <div class="allques">
                                                <div class="row quesdetailsans">
                                                    <div class="col-md-2 d-center pigmartop"><?php echo e($question->id); ?></div>
                                                    <div class="col-md-5 d-center pigmartop"><?php echo e($question->mini_question); ?></div>
                                                    <div class="col-md-3 text-center d-center pigmartop"> <i class="fas fa-calendar-alt"></i>
                                                        <?php echo e(Carbon\Carbon::parse($question->created_at)->format('d-m-Y')); ?>

                                                    </div>
                                                    <div class="col-md-2 text-center d-center pigmartop"><h4 class="m-0"><span class="badge"></span></h4>
                                                    </div>
                                                </div>
                                                <div class="row quesmoredetails">
                                                    <div class="col-md-2"></div>
                                                    <div class="col-md-8  questext d-center pigmartop"><?php echo e($question->question); ?></div>
                                                    <div class="col-md-2  text-center trash">
                                                        <a title="" onclick="return false;" object_id="<?php echo e($question->id); ?>"
                                                           delete_url="/delete/question/" class="edit-btn-table remove-alert" href="#">
                                                            <i class="fas fa-trash-alt"></i>
                                                        </a>
                                                    </div>
                                                </div>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                                <?php else: ?>
                                <br>
                                <div class="alert alert-warning">
                                    <h3>
                                        لا يوجد اسئلة قيد الاجابة....
                                    </h3>
                                </div>
                            <?php endif; ?>
                        </div>
                        <div id="answer" class=" tab-pane fade">

                            <div class="row quesdetails">
                                <div class="col-md-2">رقم</div>
                                <div class="col-md-5">موضوع السؤال</div>
                                <div class="col-md-3 text-center">تاريخ الاجابة</div>
                                <div class="col-md-2">التعليقات</div>
                            </div>
                            <?php if(count($answered_questions) > 0): ?>
                            <table class="table example table-borderless" style="width:100%">
                                <thead style="display:none;">
                                <tr>
                                    <th hidden></th>
                                    <th></th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php $__currentLoopData = $answered_questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td hidden></td>
                                        <td>
                                            <div class="allques">
                                                <div class="row quesdetailsans">
                                                    <div class="col-md-2 d-center pigmartop"><?php echo e($question->id); ?></div>
                                                    <div class="col-md-5 d-center pigmartop">
                                                        <a href="<?php echo e(route('question.show' , $question->slug)); ?>">
                                                            <?php echo e($question->mini_question); ?>

                                                        </a>
                                                    </div>
                                                    <div class="col-md-3 text-center d-center pigmartop"> <i class="fas fa-calendar-alt"></i>
                                                        <?php echo e(Carbon\Carbon::parse($question->answered_date)->format('d-m-Y')); ?>

                                                    </div>
                                                    <div class="col-md-2 text-center d-center pigmartop">
                                                        <h4 class="m-0">
                                                            <span class="badge">
                                                                <?php echo e(count($question->comments)); ?>

                                                            </span>
                                                        </h4>
                                                    </div>
                                                </div>
                                                <div class="row quesmoredetails">
                                                    <div class="col-md-2"></div>
                                                    <div class="col-md-8  questext d-center pigmartop">
                                                        <?php echo e($question->question); ?>

                                                    </div>
                                                    <div class="col-md-2  text-center trash">
                                                        <a title="" onclick="return false;" object_id="<?php echo e($question->id); ?>"
                                                           delete_url="/delete/question/" class="edit-btn-table remove-alert" href="#">
                                                            <i class="fas fa-trash-alt"></i>
                                                        </a>
                                                    </div>
                                                </div>
                                                <?php if(count($question->comments) > 0): ?>
                                                    <div class="anscomment">
                                                        <h3 class="commenttitle">
                                                            التعليقات على السؤال
                                                        </h3>
                                                        <?php $__currentLoopData = $question->comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <p class="textcomment">
                                                            <?php echo e($comment->comment); ?>

                                                            <?php if(!$loop->last): ?>
                                                                <hr>
                                                                <?php endif; ?>
                                                                </p>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </div>
                                                <?php endif; ?>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                            <?php else: ?>
                                <br>
                                <div class="alert alert-warning">
                                    <h3>
                                        لا يوجد اسئلة تم الاجابة عليها ....
                                    </h3>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div>
</div><?php /**PATH H:\laravel blogs\shobohat\resources\views/frontend/profile/content_sections/question.blade.php ENDPATH**/ ?>