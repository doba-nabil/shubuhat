<?php $__env->startSection('pageTitle', 'المقالات'); ?>
<?php $__env->startSection('frontend-main'); ?>
    <!-- tabs  -->
    <div class="tabs">
        <div class="container">

            <div class="title">
                <h4 class="sectiontitle mb-5">
                    المقالات
                </h4>
            </div>
            <div class="alltabs">
                <div class="content">
                    <div class="tab-content">
                        <div id="artical" class=" tab-pane active">
                            <table id="example" class="table  table-borderless">
                                <thead style="display:none;">
                                <tr>
                                    <th hidden></th>
                                    <th></th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td hidden></td>
                                        <td>
                                            <div class="allvideo d-colm">
                                                <div class="rightsec d-colm">
                                                    <div class="secimg">
                                                        <?php if(isset($article->mainImage->image)): ?>
                                                            <img src="<?php echo e(asset('pictures/media/' . $article->mainImage->image)); ?>"
                                                                 alt="<?php echo e($article->title); ?>">
                                                        <?php else: ?>
                                                            <img src="<?php echo e(asset('frontend/img/empty.png')); ?>" alt="" />
                                                        <?php endif; ?>

                                                    </div>
                                                    <div class="viddeta d-colm">
                                                        <p class="namev"><?php echo e($article->title); ?></p>
                                                        <p class="catv"><?php echo e($article->category->title); ?></p>
                                                        <p class="timev"><?php echo e(Carbon\Carbon::parse($article->created_at)->format('d-m-Y')); ?></p>
                                                    </div>
                                                </div>
                                                <div class="leftsec">
                                                    <a href="<?php echo e(route('article.show' , $article->slug)); ?>" type="button" class="btn shahed">
                                                        تصفح
                                                    </a>
                                                </div>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- ens tabs  -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('frontend-footer'); ?>
    <script src="https://cdn.datatables.net/1.10.21/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.10.21/js/dataTables.bootstrap4.min.js"></script>
    <script>
        $(document).ready(function () {
            $('#example').DataTable({
                "language": {
                    "url": "<?php echo e(asset('frontend/js/ar_table.json')); ?>"
                }
            });
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/nej76515k7il/public_html/resources/views/frontend/article/articles.blade.php ENDPATH**/ ?>