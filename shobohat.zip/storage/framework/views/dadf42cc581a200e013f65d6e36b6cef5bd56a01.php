<div id="London" class="tabcontent">
    <div class="firsttab pigmartop">
        <!--  callus  -->
        <div class="callus">
            <div class="aboutus">
                <div class="">
                    <div class="allaboutus">
                        <form method="post" action="<?php echo e(route('editprofile')); ?>" class="formsty pt-0 pb-2 ">
                            <?php echo csrf_field(); ?>
                            <?php echo e(method_field('PATCH')); ?>

                            <div class="form-group">
                                <label for="exampleFormControlInput1">الإسم</label>
                                <input class="form-control" id="exampleFormControlInput1" value="<?php echo e($user->name); ?>"
                                       readonly="">
                            </div>
                            <div class="form-group">
                                <label for="exampleFormControlInput1">البريد الإلكترونى</label>
                                <input type="email" name="email" class="form-control" id="exampleFormControlInput1"
                                       value="<?php echo e($user->email); ?>">
                                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="text-danger"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="form-group">
                                <label for="phone">رقم الهاتف </label>
                                <input type="text" name="phone" class="form-control" id="phone" value="<?php echo e($user->phone); ?>"
                                       placeholder="+9669999999">
                                <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="text-danger"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="form-group">
                                <label for="religion">الديانة </label>
                                <input type="text" name="religion" class="form-control" id="religion" value="<?php echo e($user->religion); ?>"
                                placeholder="الديانة">
                                <?php $__errorArgs = ['religion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="text-danger"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="form-group">
                                <label for="social_status">الحالة الاجتماعية</label>
                                <select class="form-control" name="social_status">
                                    <option <?php if(empty($user->social_status)): ?>
                                            selected
                                            <?php endif; ?>
                                            hidden disabled>اختر الحالة الاجتماعية
                                    </option>
                                    <option
                                            <?php if($user->social_status == 'اعزب'): ?>
                                            selected
                                            <?php endif; ?>
                                            value="اعزب">اعزب
                                    </option>
                                    <option
                                            <?php if($user->social_status == 'مطلق'): ?>
                                            selected
                                            <?php endif; ?>
                                            value="مطلق">مطلق
                                    </option>
                                    <option
                                            <?php if($user->social_status == 'متزوج'): ?>
                                            selected
                                            <?php endif; ?>
                                            value="متزوج">متزوج
                                    </option>
                                    <option
                                            <?php if($user->social_status == 'ارمل'): ?>
                                            selected
                                            <?php endif; ?>
                                            value="ارمل">ارمل
                                    </option>
                                </select>
                                <?php $__errorArgs = ['social_status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="text-danger"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="form-group">
                                <label for="gender">الجنس</label>
                                <select class="form-control" name="gender">
                                    <option <?php if(empty($user->gender)): ?>
                                            selected
                                            <?php endif; ?>
                                            hidden disabled>اختر الجنس
                                    </option>
                                    <option
                                            <?php if($user->social_status = 'انثى'): ?>
                                            selected
                                            <?php endif; ?>
                                            value="انثى">انثى
                                    </option>
                                    <option
                                            <?php if($user->social_status = 'ذكر'): ?>
                                            selected
                                            <?php endif; ?>
                                            value="ذكر">ذكر
                                    </option>
                                </select>
                                <?php $__errorArgs = ['gender'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="text-danger"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="firstbtn text-center mb-2">
                                <button class="btn btnformse">حفظ</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        <!-- end callus  -->
    </div>
</div>


<?php /**PATH /home/nej76515k7il/public_html/resources/views/frontend/profile/content_sections/edit_profile.blade.php ENDPATH**/ ?>