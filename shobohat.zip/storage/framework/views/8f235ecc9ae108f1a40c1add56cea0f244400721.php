<!DOCTYPE html>
<html class="loading" lang="en" data-textdirection="rtl">
<head>
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <?php echo $__env->make('backend.layout.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>

<body class="vertical-layout vertical-menu-modern 2-columns  navbar-floating footer-static  <?php if(Auth::user()->dark_mode == 1): ?> dark-layout <?php endif; ?>"
      data-open="click" data-menu="vertical-menu-modern" data-col="2-columns" data-layout="dark-layout">

<input type="hidden" value="<?php echo e(URL::to('/')); ?>" id="base_url">
<!--Preloader-->
<div class="preloader-it">
    <div class="la-anim-1"></div>
</div>
<div class="wrapper theme-1-active pimary-color-red">
    <!-- Top Menu Items -->
<?php echo $__env->make('backend.layout.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<!-- Left Sidebar Menu -->
<?php echo $__env->make('backend.layout.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- /Left Sidebar Menu -->

    <!-- Main Content -->
    <!-- BEGIN: Content-->
    <div class="app-content content">
        <div class="content-overlay"></div>
        <div class="header-navbar-shadow"></div>
        <div class="content-wrapper">
            <div class="content-header row">
            </div>
            <div class="content-body">
                <?php $__env->startSection('backend-main'); ?>
                <?php echo $__env->yieldSection(); ?>
            </div>
        </div>
    </div>
    <!-- /Main Content -->
    <div class="sidenav-overlay"></div>
    <div class="drag-target"></div>
    <!-- BEGIN: Footer-->
    <footer class="footer footer-static footer-light">
        <p class="clearfix blue-grey lighten-2 mb-0"><span class="float-md-left d-block d-md-inline-block mt-25">COPYRIGHT &copy; 2020<a
                        class="text-bold-800 grey darken-2" href="#"
                        target="_blank"></a>All rights Reserved</span><span
                    class="float-md-right d-none d-md-block">Hand-crafted & Made with<i
                        class="feather icon-heart pink"></i></span>
            <button class="btn btn-primary btn-icon scroll-top" type="button"><i class="feather icon-arrow-up"></i>
            </button>
        </p>
    </footer>
    <!-- END: Footer-->
</div>
<!-- /#wrapper -->
<?php if(Auth::user()->dark_mode == 0): ?>
    <script>
        document.getElementById("light_btn").style.display = "none";
    </script>
<?php else: ?>
    <script>
        document.getElementById("dark_btn").style.display = "none";
    </script>
<?php endif; ?>
<?php echo $__env->make('backend.layout.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>
</html><?php /**PATH H:\laravel blogs\shobohat\resources\views/backend/layout/master.blade.php ENDPATH**/ ?>