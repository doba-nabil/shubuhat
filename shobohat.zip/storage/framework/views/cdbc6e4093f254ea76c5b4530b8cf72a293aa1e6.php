<?php $__env->startSection('frontend-head'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('pageTitle', $page->title); ?>
<?php $__env->startSection('frontend-main'); ?>
    <!--  aboutus  -->
    <div class="aboutus">
        <div class="container">
            <div class="allaboutus">
                <div class="title">
                    <h4 class="titleabout">
                        <?php echo e($page->title); ?>

                    </h4>
                </div>
                <div class="totalaboutus text-center">
                    <?php if(isset($page->mainImage->image)): ?>
                        <div class="aboutimg text-center">
                            <img src="<?php echo e(asset('pictures/pages/' . $page->mainImage->image)); ?>"
                                 alt="<?php echo e($page->title); ?>">
                        </div>
                    <?php endif; ?>
                    <div class="abouttext">
                        <p>
                            <?php echo htmlspecialchars_decode($page->text) ?>
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- end shobohat  -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/nej76515k7il/public_html/resources/views/frontend/page.blade.php ENDPATH**/ ?>