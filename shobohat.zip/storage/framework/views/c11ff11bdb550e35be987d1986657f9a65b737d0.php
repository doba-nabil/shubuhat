<?php $__env->startSection('frontend-head'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('pageTitle', ' تسجيل جديد'); ?>
<?php $__env->startSection('frontend-main'); ?>
    <!--  callus  -->
    <div class="callus">
        <div class="aboutus">
            <div class="container">
                <div  style="width:100%" class="loginform">
                                    <div class="top">
                                        <div class="textfo">
                                            <h3>أهلاً بعودتك</h3>
                                            <p>قم بتسجيل الدخول لموقع شبهات</p>
                                        </div>
                                        <img src="<?php echo e(asset('frontend')); ?>/img/Image 10.png" alt="banner">
                                    </div>
                                    <div class="logformsty">
                                        <img src="<?php echo e(asset('frontend')); ?>/img/222.png" alt="logo">
                                        <form method="POST" action="<?php echo e(route('login')); ?>" class="login_form">
                                            <?php echo csrf_field(); ?>
                                            <div class="form-group">
                                                <label for="email">البريد الإلكترونى</label>
                                                <input type="email" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                       name="email" value="<?php echo e(old('email')); ?>" required autocomplete="email"
                                                       placeholder="Admin@engaz.com">
                                                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <span class="invalid-feedback" role="alert">
                                                        <strong><?php echo e($message); ?></strong>
                                                    </span>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                            <div class="form-group">
                                                <label for="pass">كلمة المرور </label>
                                                <input type="password" class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                       name="password" required autocomplete="current-password">
                                                <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <span class="invalid-feedback" role="alert">
                                                        <strong><?php echo e($message); ?></strong>
                                                    </span>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                            <div class="form-group row">
                                                <div class="col-sm-10">
                                                    <div class="form-check">
                                                        <input class="form-check-input" type="checkbox" name="remember" id="remember" <?php echo e(old('remember') ? 'checked' : ''); ?>>
                                                        <label class="form-check-label" for="gridCheck">
                                                            تذكرنى
                                                        </label>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="form-group row">
                                                <div class="col-md-12">
                                                    <button type="submit" class="btn loginfornsty">تسجيل الدخول</button>
                                                </div>
                                            </div>
                                        </form>
                                        
                                        
                                            
                                            
                                        

                                    </div>
                                </div>
            </div>
        </div>
    </div>
    <!-- end callus  -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/nej76515k7il/public_html/resources/views/auth/login.blade.php ENDPATH**/ ?>