<?php $__env->startSection('frontend-head'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('pageTitle', 'الرئيسية'); ?>
<?php $__env->startSection('frontend-main'); ?>
    <!-- search  -->
    <div class="search">
        <div class="container">
            <form method="post" action="<?php echo e(route('catSearch')); ?>">
                <?php echo csrf_field(); ?>
                <div class="search">
                    <div class="allsea">
                        <input name="word" class="form-control" type="text"
                               placeholder="إبحث عن شبهات عن طريق الشبهة او رقمها">
                        <button type="submit"><i class="fas fa-search"></i></button>
                    </div>
                </div>
            </form>
        </div>
    </div>
    <!-- end search  -->
    <!-- new shobohat  -->
    <div class="shobohat">
        <div class="container">
            <div class="allshobohat">
                <div class="title">
                    <h4 class="titleshop">
                        شبهات جديدة
                    </h4>
                </div>
                <div class="totaltotal">
                    <table class="table example table-borderless" style="width:100%">
                        <thead style="display:none;">
                        <tr>
                            <th hidden></th>
                            <th></th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td hidden></td>
                                <td>
                                    <div class="totalshob">
                                            <span hidden>
                                                <?php echo e($question->id); ?>

                                            </span>
                                        <div class="oneshob d-colm">
                                            <div class="rightshob d-colm">
                                                <?php if(auth()->guard()->check()): ?>
                                                    <?php
                                                    $likee = \App\Models\Favourite::where('question_id', $question->id)->where('user_id', Auth::user()->id)->count();
                                                    ?>
                                                    <?php if($likee > 0): ?>
                                                        <a role="button" class="favourite_add color"
                                                           ad="<?php echo e($question->id); ?>" data-token="<?php echo e(csrf_token()); ?>">
                                                            <i class="far fa-bookmark"></i>
                                                        </a>
                                                    <?php else: ?>
                                                        <a role="button" class="favourite_add" ad="<?php echo e($question->id); ?>"
                                                           data-token="<?php echo e(csrf_token()); ?>">
                                                            <i class="far fa-bookmark"></i>
                                                        </a>
                                                    <?php endif; ?>
                                                <?php else: ?>
                                                    <button type="button" class="btn" data-toggle="modal" data-target="#like">
                                                        <i class="far fa-bookmark"></i>
                                                    </button>
                                                <?php endif; ?>
                                                <a href="<?php echo e(route('question.show' , $question->slug)); ?>">
                                                    <p class="d-center">
                                                        <?php echo e($question->mini_question); ?>

                                                    </p>
                                                </a>
                                            </div>
                                            <div class="leftshob pigmartop">
                                                <a href="<?php echo e(route('question.show' , $question->slug)); ?>">
                                                    <p class="pigmartop">
                                                        <?php echo e(Carbon\Carbon::parse($question->answered_date)->format('d-m-Y')); ?>

                                                    </p>
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                    <div class="moretab ">
                        <p style="color: #ffffff" class="text-right"><a href="<?php echo e(route('question.index')); ?>">المزيد . . .</a></p>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- now shobohat  -->
    <!-- banar  -->
    <?php if(isset($option->banner_image)): ?>
    <div class="banar mt-5">
        <div class="overlaypar">
            <a href="<?php echo e($option->banner_link); ?>">
                <img src="<?php echo e(asset('pictures/options/' . $option->banner_image->image)); ?>" alt='<?php echo e($option->banner_title); ?>'>
                <div class="overlaychi"></div>
                <h3><?php echo e($option->banner_title); ?></h3>
            </a>
        </div>
    </div>
    <?php endif; ?>
    <!--end banar  -->
    <!-- tabs  -->
    <div class="tabs">
        <div class="container">

            <div class="title">
                <h4 class="sectiontitle mb-5">
                    مكتبة الوسائط
                </h4>
            </div>

            <div class="alltabs">

                <div class="content">
                    <!-- Nav pills -->
                    <ul class="nav nav-pills" role="tablist">
                        <li class="nav-item">
                            <a class="nav-link active" data-toggle="pill" href="#vdio">
                                <i class="fas fa-video"></i>
                                فيديوهات</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" data-toggle="pill" href="#record">
                                <i class="fas fa-volume-down"></i>
                                صوتيات</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" data-toggle="pill" href="#book">
                                <i class="fas fa-book"></i>
                                كتب</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" data-toggle="pill" href="#artical">
                                <i class="far fa-newspaper"></i>
                                مقالات</a>
                        </li>
                    </ul>

                    <!-- Tab panes -->
                    <div class="tab-content">
                        <div id="vdio" class=" tab-pane active">
                            <?php if(count($videos) > 0): ?>
                                <?php $__currentLoopData = $videos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $video): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="allvideo d-colm">
                                        <div class="rightsec d-colm">
                                            <div class="secimg d-center">
                                                <?php if(isset($video->mainImage->image)): ?>
                                                    <img src="<?php echo e(asset('pictures/media/' . $video->mainImage->image)); ?>">
                                                <?php else: ?>
                                                    <img src="<?php echo e(asset('frontend/img/empty.png')); ?>" alt=""/>
                                                <?php endif; ?>

                                                <div class="overlaysec"><i class="far fa-play-circle"></i></div>
                                            </div>
                                            <div class="viddeta d-colm">
                                                <p class="namev"><?php echo e($video->title); ?></p>
                                                <p class="catv"><?php echo e($video->category->title ?? ''); ?></p>
                                                <p class="timev"><?php echo e(Carbon\Carbon::parse($video->created_at)->format('d-m-Y')); ?></p>
                                            </div>
                                        </div>
                                        <div class="leftsec">
                                            <!-- Button trigger modal -->
                                            <button type="button" class="btn shahed" data-toggle="modal"
                                                    data-target="#exampleModalCenter<?php echo e($video->slug); ?>">
                                                مشاهدة
                                            </button>
                                            <!-- Modal -->
                                            <div class="modal fade" id="exampleModalCenter<?php echo e($video->slug); ?>"
                                                 tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle"
                                                 aria-hidden="true">
                                                <div class="modal-dialog modal-dialog-centered" role="document">
                                                    <div class="modal-content">
                                                        <div class="modal-header">
                                                            <h5 class="modal-title"
                                                                id="exampleModalLongTitle"><?php echo e($video->title); ?></h5>
                                                            <button type="button" class="close" data-dismiss="modal"
                                                                    aria-label="Close">
                                                                <span aria-hidden="true">&times;</span>
                                                            </button>
                                                        </div>
                                                        <div class="modal-body text-center">
                                                            <?php if(isset($video->file->file)): ?>
                                                                <video width="420" height="340" controls>
                                                                    <source src="<?php echo e(asset('pictures/video/' . $video->file->file)); ?>">
                                                                </video>
                                                            <?php elseif($video->file->link): ?>
                                                                <?php
                                                                $string     =  $video->file->link ;
                                                                $search     = '/youtube\.com\/watch\?v=([a-zA-Z0-9]+)/smi';
                                                                $replace    = "youtube.com/embed/$1";
                                                                $url = preg_replace($search,$replace,$string);
                                                                ?>
                                                                <iframe width="420" height="340"
                                                                        src='<?php echo e($url); ?>?modestbranding=1'
                                                                        allowfullscreen>
                                                                </iframe>
                                                            <?php endif; ?>
                                                        </div>
                                                        <div class="modal-footer">
                                                            <button type="button" class="btn btn-secondary"
                                                                    data-dismiss="modal">اغلاق
                                                            </button>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <div class="moretab ">
                                    <p class="text-right"><a href="<?php echo e(route('video.index')); ?>">المزيد . . .</a></p>
                                </div>
                            <?php else: ?>
                                <div class="alert alert-warning">
                                    <h4>
                                        لا يوجد فيديوهات بعد ....
                                    </h4>
                                </div>
                            <?php endif; ?>
                        </div>
                        <div id="record" class=" tab-pane fade">
                            <?php if(count($audios) > 0): ?>
                                <?php $__currentLoopData = $audios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $audio): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="allaudio <?php if(empty($audio->file->file)): ?> allvideo <?php endif; ?>">
                                        <h4 <?php if(empty($audio->file->file)): ?> class="text-center" <?php endif; ?>>
                                            <?php echo e($audio->title); ?>

                                            <?php if(empty($audio->file->file)): ?>
                                                <img class="" width="120px"
                                                     src="<?php echo e(asset('frontend/img/sound.png')); ?>">
                                            <?php endif; ?>
                                        </h4>
                                        <p class="adiotext"><?php echo e($audio->subtitle); ?></p>
                                        <?php if(!empty($audio->file->file)): ?>
                                            <div class="ready-player-<?php echo e($audio->id); ?>">
                                                <audio>
                                                    <source src="<?php echo e(asset('pictures/audio/' . $audio->file->file)); ?>">
                                                </audio>
                                            </div>
                                        <?php else: ?>
                                            <div class="modal fade" id="exampleModalCenter<?php echo e($audio->slug); ?>"
                                                 tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle"
                                                 aria-hidden="true">
                                                <div class="modal-dialog modal-dialog-centered" role="document">
                                                    <div class="modal-content">
                                                        <div class="modal-header">
                                                            <h5 class="modal-title"
                                                                id="exampleModalLongTitle"><?php echo e($audio->title); ?></h5>
                                                            <button type="button" class="close" data-dismiss="modal"
                                                                    aria-label="Close">
                                                                <span aria-hidden="true">&times;</span>
                                                            </button>
                                                        </div>
                                                        <div class="modal-body text-center">
                                                            <div>
                                                                <?php echo $audio->file->link; ?>

                                                                <div class="clearfix"></div>
                                                            </div>
                                                        </div>
                                                        <div class="modal-footer">
                                                            <button type="button" class="btn btn-secondary"
                                                                    data-dismiss="modal">اغلاق
                                                            </button>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="leftsec">
                                                <!-- Button trigger modal -->
                                                <button type="button" class="btn shahed" data-toggle="modal"
                                                        data-target="#exampleModalCenter<?php echo e($audio->slug); ?>">
                                                    استماع
                                                </button>
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <div class="moretab ">
                                    <p class="text-right"><a href="<?php echo e(route('audio.index')); ?>">المزيد . . .</a></p>
                                </div>
                            <?php else: ?>
                                <div class="alert alert-warning">
                                    <h4>
                                        لا يوجد صوتيات بعد ....
                                    </h4>
                                </div>
                            <?php endif; ?>
                        </div>
                        <div id="book" class=" tab-pane fade">
                            <?php if(count($books) > 0): ?>
                                <?php $__currentLoopData = $books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="allvideo d-colm">
                                        <div class="rightsec d-colm">
                                            <div class="secimg">
                                                <?php if(isset($book->mainImage->image)): ?>
                                                    <img src="<?php echo e(asset('pictures/media/' . $book->mainImage->image)); ?>">
                                                <?php else: ?>
                                                    <img src="<?php echo e(asset('frontend/img/empty.png')); ?>" alt=""/>
                                                <?php endif; ?>

                                            </div>
                                            <div class="viddeta d-colm">
                                                <p class="namev"><?php echo e($book->title); ?></p>
                                                <p class="catv"><?php echo e($book->category->title); ?></p>
                                                <p class="timev"><?php echo e(Carbon\Carbon::parse($book->created_at)->format('d-m-Y')); ?></p>
                                            </div>
                                        </div>
                                        <div class="leftsec d-colm">
                                            <a class="pigmarbot" href="<?php echo e(route('book.show' , $book->slug)); ?>">
                                                <button type="button" class="btn shahed">
                                                    نبذة
                                                </button>
                                            </a>
                                            <a class="pigmarbot" href="<?php echo e(asset('pictures/books/' . $book->file->file)); ?>"
                                               target="_blank">
                                                <button type="button" class="btn shahed">
                                                    تصفح
                                                </button>
                                            </a>
                                            <button type="button" class="btn shahed-dwon">
                                                <a href="<?php echo e(asset('pictures/books/' . $book->file->file)); ?>"
                                                   download="">
                                                    تحميل
                                                    <i class="fa fa-download"></i>
                                                </a>
                                            </button>
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <div class="moretab ">
                                    <p class="text-right"><a href="<?php echo e(route('book.index')); ?>">المزيد . . .</a></p>
                                </div>
                            <?php else: ?>
                                <div class="alert alert-warning">
                                    <h4>
                                        لا يوجد كتب بعد ....
                                    </h4>
                                </div>
                            <?php endif; ?>
                        </div>
                        <div id="artical" class=" tab-pane fade">
                            <?php if(count($articles) > 0): ?>
                                <?php $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="allvideo d-colm">
                                        <div class="rightsec d-colm">
                                            <div class="secimg">
                                                <?php if(isset($article->mainImage->image)): ?>
                                                    <img src="<?php echo e(asset('pictures/media/' . $article->mainImage->image)); ?>"
                                                         alt="<?php echo e($article->title); ?>">
                                                <?php else: ?>
                                                    <img src="<?php echo e(asset('frontend/img/empty.png')); ?>" alt=""/>
                                                <?php endif; ?>
                                            </div>
                                            <div class="viddeta d-colm">
                                                <p class="namev"><?php echo e($article->title); ?></p>
                                                <p class="catv"><?php echo e($article->category->title); ?></p>
                                                <p class="timev"><?php echo e(Carbon\Carbon::parse($article->created_at)->format('d-m-Y')); ?></p>
                                            </div>
                                        </div>
                                        <div class="leftsec">
                                            <a href="<?php echo e(route('article.show' , $article->slug)); ?>">
                                                <button type="button" class="btn shahed">
                                                    تصفح
                                                </button>
                                            </a>
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <div class="moretab ">
                                    <p class="text-right"><a href="<?php echo e(route('article.index')); ?>">المزيد . . .</a></p>
                                </div>
                            <?php else: ?>
                                <div class="alert alert-warning">
                                    <h4>
                                        لا يوجد مقالات بعد ....
                                    </h4>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- ens tabs  -->

    <!-- different -->
    <div class="different mb-5">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="titledef">
                        <h4>ملفات متنوعة</h4>
                    </div>
                </div>
                <div class="col-md-8 taall">
                    <div class="owl1 owl-carousel owl-carousel1 owl-theme">
                        <?php $__currentLoopData = $folders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $folder): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="item">
                                <div class="totalimg">
                                    <a class="imgmain" href="<?php echo e(route('folder.show' , $folder->slug)); ?>">
                                        <?php if(isset($folder->mainImage->image)): ?>
                                            <img src="<?php echo e(asset('pictures/folders/' . $folder->mainImage->image)); ?>"
                                                 alt="<?php echo e($folder->title); ?>">
                                        <?php else: ?>
                                            <img src="<?php echo e(asset('frontend/img/empty.png')); ?>" alt=""/>
                                        <?php endif; ?>
                                    </a>
                                </div>
                                <div class="text">
                                    <p><a href="<?php echo e(route('folder.show' , $folder->slug)); ?>"
                                          class="textshow"><?php echo e($folder->title); ?></a></p>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <div class="moredif">
                        <p class="text-right">
                            <a href="<?php echo e(route('folder.index')); ?>">
                                <i class="far fa-newspaper"></i>
                                المزيد من الملفات المتنوعة
                            </a>
                        </p>
                    </div>
                </div>
                <div class="col-md-4 ">
                    <div class="totimg">
                        <a href="<?php echo e(url($option->folders_link)); ?>">
                            
                                
                            
                            <?php if(isset($option->banner_image->image)): ?>
                                <img src="<?php echo e(asset('pictures/options/' . $option->folder_ad->image)); ?>" alt="">
                            <?php else: ?>
                                <img src="<?php echo e(asset('frontend/img/empty.png')); ?>" alt=""/>
                            <?php endif; ?>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!--end different -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('frontend-footer'); ?>
    <?php $__currentLoopData = $audios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $audio): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if(!empty($audio->file->file)): ?>
            <script>
                document.addEventListener('DOMContentLoaded', function () {
                    new GreenAudioPlayer('.ready-player-<?php echo e($audio->id); ?>', {
                        showTooltips: true,
                        showDownloadButton: false,
                        enableKeystrokes: true
                    });
                });
            </script>
        <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH H:\laravel blogs\shobohat\resources\views/frontend/home.blade.php ENDPATH**/ ?>