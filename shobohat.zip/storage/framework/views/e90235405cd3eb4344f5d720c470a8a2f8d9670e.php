<?php $__env->startSection('frontend-head'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('pageTitle', 'الملفات المتنوعة'); ?>
<?php $__env->startSection('frontend-main'); ?>
    <div class="container">
        <div class="row">
            <div class="col-lg-12 my-3">
                <div class="pull-right my-5">
                    <div class="btn-group">
                        <h4>ملفات متنوعة</h4>
                        <div class="listgridbtnres">
                            <button class="btn" id="list">
                                <i class="fas fa-list"></i>
                            </button>
                            <button class="btn " id="grid">
                                <i class="fas fa-th"></i>
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div id="products" class="row view-group folders-doba">
            <?php echo $__env->make('frontend.folder.pagination_data', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('frontend-footer'); ?>
    <script>
        $(document).ready(function(){
            $(document).on('click', '.pagination a', function(event){
                event.preventDefault();
                var page = $(this).attr('href').split('page=')[1];
                fetch_data(page);
            });
            function fetch_data(page)
            {
                $.ajax({
                    url:"/pagination/folders?page="+page,
                    success:function(data)
                    {
                        $('#products').html(data);
                    }
                });
            }
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/nej76515k7il/public_html/resources/views/frontend/folder/folders.blade.php ENDPATH**/ ?>