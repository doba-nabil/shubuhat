<?php $__env->startSection('backend-footer'); ?>
<?php echo $__env->yieldSection(); ?>
<!-- BEGIN: sweett alert JS-->
<script src="<?php echo e(asset('backend')); ?>/app-assets/vendors/js/extensions/sweetalert2.all.min.js"></script>
<script src="<?php echo e(asset('backend')); ?>/app-assets/vendors/js/extensions/polyfill.min.js"></script>
<script src="<?php echo e(asset('backend')); ?>/app-assets/js/scripts/ui/data-list-view.js"></script>
<script src="<?php echo e(asset('backend')); ?>/app-assets/js/scripts/extensions/sweet-alerts.js"></script>
<!-- END: sweett alert JS-->
<script src="<?php echo e(asset('backend')); ?>/custom-sweetalert.js"></script>
<script src="<?php echo e(asset('backend')); ?>/mine.js"></script>
<script>
    var base_url = $('#base_url').val();
    $('.marked_as_read').click(function() {
        var token = $(this).data('token');
        var id = $(this).attr('notification');
        $.ajax({
            url: base_url + '/read',
            type: 'post',
            data: '_token=' + token + '&notificationID=' + id,
            dataType: 'json',
        });
    });
</script>
<?php /**PATH /home/nej76515k7il/public_html/resources/views/backend/layout/footer.blade.php ENDPATH**/ ?>