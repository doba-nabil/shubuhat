<?php $__env->startSection('pageTitle', 'الصوتيات'); ?>
<?php $__env->startSection('frontend-main'); ?>
    <!-- tabs  -->
    <div class="tabs">
        <div class="container">
            <div class="title">
                <h4 class="sectiontitle mb-5">
                    الصوتيات
                </h4>
            </div>
            <div class="alltabs">
                <div class="content">
                    <div class="tab-content">
                        <div id="record" class=" tab-pane active">
                        <table id="example" class="table  table-borderless" style="width:100%">
                            <thead style="display:none;">
                            <tr>
                                <th hidden></th>
                                <th></th>
                            </tr>
                            </thead>
                            <tbody>

                            <?php $__currentLoopData = $audios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $audio): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td hidden></td>
                                    <td>
                                        <div class="allaudio <?php if(empty($audio->file->file)): ?> allvideo <?php endif; ?>">
                                            <h4 <?php if(empty($audio->file->file)): ?> class="text-center" <?php endif; ?>>
                                                <?php echo e($audio->title); ?>

                                                <?php if(empty($audio->file->file)): ?>
                                                    <img class="" width="120px"
                                                         src="<?php echo e(asset('frontend/img/sound.png')); ?>">
                                                <?php endif; ?>
                                            </h4>
                                            <p class="adiotext"><?php echo e($audio->subtitle); ?></p>
                                        <?php if(!empty($audio->file->file)): ?>
                                                <div class="ready-player-<?php echo e($audio->id); ?>">
                                                    <audio>
                                                        <source src="<?php echo e(asset('pictures/audio/' . $audio->file->file)); ?>">
                                                    </audio>
                                                </div>
                                            <?php else: ?>
                                                <div class="modal fade" id="exampleModalCenter<?php echo e($audio->slug); ?>"
                                                     tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle"
                                                     aria-hidden="true">
                                                    <div class="modal-dialog modal-dialog-centered" role="document">
                                                        <div class="modal-content">
                                                            <div class="modal-header">
                                                                <h5 class="modal-title"
                                                                    id="exampleModalLongTitle"><?php echo e($audio->title); ?></h5>
                                                                <button type="button" class="close" data-dismiss="modal"
                                                                        aria-label="Close">
                                                                    <span aria-hidden="true">&times;</span>
                                                                </button>
                                                            </div>
                                                            <div class="modal-body text-center">
                                                                <div>
                                                                    <?php echo $audio->file->link; ?>

                                                                    <div class="clearfix"></div>
                                                                </div>
                                                            </div>
                                                            <div class="modal-footer">
                                                                <button type="button" class="btn btn-secondary"
                                                                        data-dismiss="modal">اغلاق
                                                                </button>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="leftsec">
                                                    <!-- Button trigger modal -->
                                                    <button type="button" class="btn shahed" data-toggle="modal"
                                                            data-target="#exampleModalCenter<?php echo e($audio->slug); ?>">
                                                        استماع
                                                    </button>
                                                </div>
                                            <?php endif; ?>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- ens tabs  -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('frontend-footer'); ?>
    <script src="https://cdn.datatables.net/1.10.21/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.10.21/js/dataTables.bootstrap4.min.js"></script>
    <script>
        $(document).ready(function () {
            $('#example').DataTable({
                "language": {
                    "url": "<?php echo e(asset('frontend/js/ar_table.json')); ?>"
                }
            });
        });
    </script>
    <?php $__currentLoopData = $audios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $audio): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if(!empty($audio->file->file)): ?>
            <script>
                document.addEventListener('DOMContentLoaded', function() {
                    new GreenAudioPlayer('.ready-player-<?php echo e($audio->id); ?>', { showTooltips: true, showDownloadButton: false, enableKeystrokes: true });
                });
            </script>
        <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/nej76515k7il/public_html/resources/views/frontend/audio/audios.blade.php ENDPATH**/ ?>